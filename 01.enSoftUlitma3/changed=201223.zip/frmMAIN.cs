﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using enCaptureUltima3.deviceRUN;
using System.Diagnostics;

namespace enCaptureUltima3
{
    public partial class frmMAIN : Form
    {
        private int m_nTimerCount = 0;
        private clsTHREAD[] m_pTHREAD = new clsTHREAD[clsJASON.MAX_EN_DEVICE_COUNT];
        private bool m_bSecsRun = false;

        public frmMAIN()
        {
            InitializeComponent();
        }

        private void frmMAIN_Load(object sender, EventArgs e)
        {
            //panelDEVICE.Controls.Add(new ultima2View());
            Timer pTimer = new Timer();
            pTimer.Interval = 500;
            pTimer.Tick += PTimer_Tick;
            pTimer.Start();
        }

        private void PTimer_Tick(object sender, EventArgs e)
        {
            Timer timer = (Timer)sender;
            timer.Stop();
            switch (m_nTimerCount)
            {
                case 0:
                    setLayout();
                    break;
                case 1:
                    trainOCR();
                    break;
                case 2:
                    //timer.Interval = 10 * 1000;
                    runThread();
                    break;
                default:
                    if (m_bSecsRun == false)
                    {
                        if (m_pTHREAD[0].m_pCapsuleInfo.m_pAverDevice.m_bIsStartStreaming == true)
                        {
                            m_bSecsRun = true;
                            timer.Interval = (20 * 1000);
                            // RUN SECS MANAGER
                        }
                    }
                    break;
            }
            m_nTimerCount++;
            timer.Start();
        }

        private void frmMAIN_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (panelDEVICE.Controls.Count > 0)
            {
                for (int n = 0; n < panelDEVICE.Controls.Count; n++)
                    m_pTHREAD[n].stopAgent();
            }
        }




        ///////////////////////////////////////////////////////////////////////////////////////////////////
        /// LOCAL METHODS
        ///////////////////////////////////////////////////////////////////////////////////////////////////
        private void setLayout()
        {
            clsJASON pJason = new clsJASON();
            String strMsg = pJason.readMain();
            if (strMsg.Length > 0)
            {
                MessageBox.Show(strMsg, "WARNING");
                this.Close();
                return;
            }
            if(pJason.m_COMMON.Device < 1)
            {
                strMsg = "NO DEVICE";
                MessageBox.Show(strMsg, "WARNING");
                this.Close();
                return;
            }
            lblMAIN.Text = String.Format("DEVICE COUNT={0}", pJason.m_COMMON.Device);
            int n;
            int pointX = 3, pointY = 3;
            //panelDEVICE.Height = 606 + 8;
            for (n=0; n< pJason.m_COMMON.Device; n++)
            {
                // 534, 606
                ultima2View control = new ultima2View();
                panelDEVICE.Controls.Add(control);
                control.Location = new Point(pointX, pointY);
                control.checkView.Checked = true;
                pointX += (534 + 8);
                m_pTHREAD[n] = new clsTHREAD(n, control);
                m_pTHREAD[n].m_pCapsuleInfo.m_pAverDevice.m_PicStream = control.picSTREAM;
                m_pTHREAD[n].m_pCapsuleInfo.m_pAverDevice.m_PictureHandle = control.picSTREAM.Handle;
                m_pTHREAD[n].m_pCapsuleInfo.ThreadEvent += EventServerHandler;
            }
            pointY += (606 + 8);
            this.Height = pointY + 80;
            this.Width = pointX + 38;
        }

        private const String baseOcrFolder = @".\picOCR\";
        private void trainOCR()
        {
            enUltima3Capture.knOCR pOCR = new enUltima3Capture.knOCR();
            var traingImages = pOCR.ReadTrainingImages(baseOcrFolder, "*.png");
            if(traingImages.Count < 10)
            {
                String strMsg = String.Format("Invalid Training Image={0} from {1}", traingImages.Count, baseOcrFolder);
                MessageBox.Show(strMsg, "WARNING");
                this.Close();
                return;
            }
            for (int n = 0; n < panelDEVICE.Controls.Count; n++)
            {
                m_pTHREAD[n].m_pCapsuleInfo.m_pOCR.initKnNearest(traingImages);
                System.Threading.Thread.Sleep(200);
            }
            lblMAIN.Text = String.Format("TRAINED IMAGE={0}", traingImages.Count);
        }

        private void runThread()
        {
            clsLOG.initLogName();
            String ErrorPath = clsLOG.getErrorPath();
            Debug.WriteLine(String.Format("FOLDER={0} ==>{1}", ErrorPath, System.IO.Directory.Exists(ErrorPath)));
            for (int n = 0; n < panelDEVICE.Controls.Count; n++)
            {
                m_pTHREAD[n].runAgent();
                System.Threading.Thread.Sleep(200);
            }
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // SECS
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        // CALL-BACK from server Side
        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void EventServerHandler(Object sender, clsEventArgs e)
        {
            this.Invoke(new CaptureNotify(OnCaptureNotify), e);
        }

        public delegate void CaptureNotify(clsEventArgs e);
        public void OnCaptureNotify(clsEventArgs e)
        {
            if (e.DevNo < panelDEVICE.Controls.Count)
            {
                int devNo = e.DevNo;
                var userControl = panelDEVICE.Controls[devNo] as ultima2View;
                switch(e.Type)
                {
                    case 0:
                        if (userControl.checkView.Checked == false)
                            break;
                        userControl.lblTIME.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                        foreach (var pOcrRun in m_pTHREAD[devNo].m_pCapsuleInfo.m_pOcrRUN)
                        {
                            if (pOcrRun.DataValid == false)
                                continue;
                            if (pOcrRun.Name == "auto-idle")
                                userControl.ln1_AutoIdle.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "PPID")
                                userControl.ln1_PPID.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "PRESS-SET")
                                userControl.ln2_PressSet.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "PRESS-MON")
                                userControl.ln2_PressMon.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "STEP")
                            {
                                userControl.ln2_Step_Cur.Text = pOcrRun.DataOCR0;
                                userControl.ln2_Step_Total.Text = pOcrRun.DataOCR1;
                            }
                            else if (pOcrRun.Name == "VALVE-SET")
                                userControl.ln3_ValveSet.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "VALVE-MON")
                                userControl.ln3_ValveMon.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "RF-SET")
                                userControl.ln3_RF_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "RF-MON")
                                userControl.ln3_RF_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "RFr-SET")
                                userControl.ln3_RFr_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "RFr-MON")
                                userControl.ln3_RFr_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "GAS1-SET")
                                userControl.ln4_Gas1_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "GAS1-MON")
                                userControl.ln4_Gas1_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "GAS2-SET")
                                userControl.ln4_Gas2_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "GAS2-MON")
                                userControl.ln4_Gas2_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TEMP1-SET")
                                userControl.ln6_Temp1_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TEMP1-MON")
                                userControl.ln6_Temp1_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TEMP2-SET")
                                userControl.ln7_Temp2_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TEMP2-MON")
                                userControl.ln7_Temp2_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TEMP3-SET")
                                userControl.ln8_Temp3_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TEMP3-MON")
                                userControl.ln8_Temp3_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "EPD-SET")
                                userControl.ln9_EPD_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "EPD-MON")
                                userControl.ln9_EPD_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TIME-SET")
                                userControl.ln10_TIME_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "TIME-MON")
                                userControl.ln10_TIME_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "CYCLE-SET")
                                userControl.ln11_CYCLE_SET.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "CYCLE-MON")
                                userControl.ln11_CYCLE_MON.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "auto-end")
                                userControl.ln11_CYCLE_TEXT.Text = pOcrRun.DataOCR0;
                            else if (pOcrRun.Name == "last")
                                userControl.ln11_CYCLE_STEP.Text = pOcrRun.DataOCR0;
                        }
                        break;
                    case 1:
                        userControl.lblRUN.Text = e.MyWorkResult;
                        break;
                }
            }
        }
    }
}
