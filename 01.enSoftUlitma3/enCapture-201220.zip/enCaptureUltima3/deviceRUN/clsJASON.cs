﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using enUltima3Capture;

namespace enCaptureUltima3.deviceRUN
{
    class clsJASON
    {
        public const int MAX_EN_DEVICE_COUNT = 2;

        public List<jasonOcrRect> m_pCropItemNormal = new List<jasonOcrRect>();
        public jasonOcrRect m_RectNormal = new jasonOcrRect();

        public List<jasonOcrRect> m_pCropItemSmall = new List<jasonOcrRect>();
        public jasonOcrRect m_RectSmall = new jasonOcrRect();

        public JasonCommon m_COMMON = new JasonCommon();
        public JasonAverMedia m_AverCap = new JasonAverMedia();

        public int m_nErroSave = 60;

        private const String JASON_FILE_NAME = @".\enUltima3Run.txt";

        public String readMain()
        {
            String strMsg = "";

            if (System.IO.File.Exists(JASON_FILE_NAME) == false)
            {
                strMsg = "JASON] NOT EXISTS=" + JASON_FILE_NAME;
                return (strMsg);
            }
            String tokenName = "";
            try
            {
                String allText = System.IO.File.ReadAllText(JASON_FILE_NAME).Replace("\t", "");
                String allRead = allText.Replace(" ", "");

                JObject jObj = JObject.Parse(allRead);
                Debug.WriteLine("PARSE ALL]" + jObj.Count);
                tokenName = "COMMON";
                JToken idToken = jObj[tokenName];
                String mainString = idToken.ToString();
                JObject jDevObj = JObject.Parse(mainString);

                // "NormalMinWidth":1100,
                m_COMMON.NormalMinWidth = Convert.ToInt32(jDevObj["NormalMinWidth"].ToString());
                m_COMMON.Device = Convert.ToInt32(jDevObj["Device"].ToString());
                m_COMMON.ThreadWait = Convert.ToInt32(jDevObj["ThreadWait"].ToString());
                m_COMMON.CaptureEnable = true;
                if (jDevObj["CaptureEnable"] != null)
                {
                    if (jDevObj["CaptureEnable"].ToString() == "NO")
                        m_COMMON.CaptureEnable = false;
                }
                m_COMMON.OcrEnable = true;
                if (jDevObj["OcrEnable"] != null)
                {
                    if (jDevObj["OcrEnable"].ToString() == "NO")
                        m_COMMON.OcrEnable = false;
                }
                if (m_COMMON.Device > MAX_EN_DEVICE_COUNT)
                    m_COMMON.Device = MAX_EN_DEVICE_COUNT;
                int n;
                for(n=0; n< m_COMMON.Device; n++)
                {
                    tokenName = String.Format("Device{0}", n);
                    if (jObj[tokenName] == null)
                        break;
                }
                m_COMMON.Device = n;
                Debug.WriteLine("JASON MAIN=" + m_COMMON.Device);
            }
            catch(Exception ex)
            {
                strMsg = "MAIN READ FAILED=" + tokenName + ", ERROR=" + ex.Message;
                Debug.WriteLine(tokenName);
            }

            return (strMsg);
        }

        public void readOCR()
        {
            String strMsg = "";

            if (System.IO.File.Exists(JASON_FILE_NAME) == false)
            {
                strMsg = "JASON] NOT EXISTS=" + JASON_FILE_NAME;
                return;
            }
            String tokenName = "";
            try
            {
                String allText = System.IO.File.ReadAllText(JASON_FILE_NAME).Replace("\t", "");
                String allRead = allText.Replace(" ", "");

                JObject jObj = JObject.Parse(allRead);
                Debug.WriteLine("PARSE ALL]" + jObj.Count);
                for (int nStep = 0; nStep < 2; nStep++)
                {
                    String mainToken = "";
                    switch (nStep)
                    {
                        case 0:
                            mainToken = "OCR-NORMAL";
                            break;
                        case 1:
                            mainToken = "OCR-SMALL";
                            break;
                    }
                    tokenName = mainToken;
                    Debug.WriteLine("\t--->TOKEN]" + tokenName);
                    JToken idToken = jObj[tokenName];
                    String mainString = idToken.ToString();
                    JObject jDevObj = JObject.Parse(mainString);
                    // Debug.WriteLine(mainString);

                    // "Rect":{"Width":1271,"Height":400},
                    tokenName = "Rect";
                    idToken = jDevObj[tokenName];
                    String mainRect = idToken.ToString();
                    Debug.WriteLine(mainRect);
                    JObject jMainObj = JObject.Parse(mainRect);
                    if (nStep == 0)
                    {
                        m_RectNormal.Width = Convert.ToInt32(jMainObj["Width"].ToString());
                        m_RectNormal.Height = Convert.ToInt32(jMainObj["Height"].ToString());
                        if (jDevObj["Error-Save"] != null)
                        {
                            m_nErroSave = Convert.ToInt32(jDevObj["Error-Save"].ToString());
                            if (m_nErroSave < 0)
                                m_nErroSave = 60 * 30;
                        }
                    }
                    else
                    {
                        m_RectSmall.Width = Convert.ToInt32(jMainObj["Width"].ToString());
                        m_RectSmall.Height = Convert.ToInt32(jMainObj["Height"].ToString());
                    }
                    String runToken = "";
                    for (int n = 0; n < 100; n++)
                    {
                        runToken = "";
                        int nRunLine = -1, nRunSub = -1;
                        switch (n)
                        {
                            case 0: runToken = "Verify-SET"; break;
                            case 1: runToken = "Verify-CYCLE"; break;
                            case 2: runToken = "auto-idle"; nRunLine = 0; nRunSub = 0; break;
                            case 3: runToken = "PPID"; nRunLine = 0; nRunSub = 1; break;
                            case 4: runToken = "PRESS-SET"; nRunLine = 1; nRunSub = 0; break;
                            case 5: runToken = "PRESS-MON"; nRunLine = 1; nRunSub = 1; break;
                            case 6: runToken = "STEP"; nRunLine = 1; nRunSub = 2; break;
                            case 7: runToken = "VALVE-SET"; nRunLine = 2; nRunSub = 0; break;
                            case 8: runToken = "VALVE-MON"; nRunLine = 2; nRunSub = 1; break;
                            case 9: runToken = "RF-SET"; nRunLine = 2; nRunSub = 2; break;
                            case 10: runToken = "RF-MON"; nRunLine = 2; nRunSub = 3; break;
                            case 11: runToken = "RFr-SET"; nRunLine = 2; nRunSub = 4; break;
                            case 12: runToken = "RFr-MON"; nRunLine = 2; nRunSub = 5; break;
                            case 13: runToken = "GAS1-SET"; nRunLine = 3; nRunSub = 0; break;
                            case 14: runToken = "GAS1-MON"; nRunLine = 3; nRunSub = 1; break;
                            case 15: runToken = "GAS2-SET"; nRunLine = 3; nRunSub = 2; break;
                            case 16: runToken = "GAS2-MON"; nRunLine = 3; nRunSub = 3; break;
                            case 17: runToken = "TEMP1-SET"; nRunLine = 4; nRunSub = 0; break;
                            case 18: runToken = "TEMP1-MON"; nRunLine = 4; nRunSub = 1; break;
                            case 19: runToken = "TEMP2-SET"; nRunLine = 4; nRunSub = 2; break;
                            case 20: runToken = "TEMP2-MON"; nRunLine = 4; nRunSub = 3; break;
                            case 21: runToken = "TEMP3-SET"; nRunLine = 4; nRunSub = 4; break;
                            case 22: runToken = "TEMP3-MON"; nRunLine = 4; nRunSub = 5; break;
                            case 23: runToken = "EPD-SET"; nRunLine = 5; nRunSub = 0; break;
                            case 24: runToken = "EPD-MON"; nRunLine = 5; nRunSub = 1; break;
                            case 25: runToken = "TIME-SET"; nRunLine = 5; nRunSub = 2; break;
                            case 26: runToken = "TIME-MON"; nRunLine = 5; nRunSub = 3; break;
                            case 27: runToken = "CYCLE-SET"; nRunLine = 6; nRunSub = 0; break;
                            case 28: runToken = "CYCLE-MON"; nRunLine = 6; nRunSub = 1; break;
                            case 29: runToken = "auto-end"; nRunLine = 6; nRunSub = 2; break;
                            case 30: runToken = "last"; nRunLine = 6; nRunSub = 3; break;
                        }
                        if (runToken.Length == 0)
                            break;
                        tokenName = runToken;
                        JToken jTokRun = jDevObj[tokenName];
                        if (jTokRun != null)
                        {
                            String itemRect = jTokRun.ToString();
                            JObject jItemObj = JObject.Parse(itemRect);
                            //m_pBaseRect.Width = Convert.ToInt32(jMainObj["Width"].ToString());
                            // "Verify-SET":{"x":291,"y":8,"Width":129,"Height":22,"Type":0,"Verify":"SET"},
                            jasonOcrRect pRect = new jasonOcrRect();
                            pRect.Name = tokenName;
                            pRect.X = Convert.ToInt32(jItemObj["x"].ToString());
                            pRect.Y = Convert.ToInt32(jItemObj["y"].ToString());
                            pRect.Width = Convert.ToInt32(jItemObj["Width"].ToString());
                            pRect.Height = Convert.ToInt32(jItemObj["Height"].ToString());
                            pRect.Type = Convert.ToInt32(jItemObj["Type"].ToString());
                            pRect.Verify = jItemObj["Verify"].ToString();
                            pRect.Line = nRunLine;
                            pRect.Step = nRunSub;
                            if (nStep == 0)
                                m_pCropItemNormal.Add(pRect);
                            else
                                m_pCropItemSmall.Add(pRect);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                strMsg = "MAIN READ FAILED=" + tokenName + ", ERROR=" + ex.Message;
                Debug.WriteLine(tokenName);
            }
            Debug.WriteLine(String.Format("OCR={0} {1}, ErrorSave={2}", m_pCropItemNormal.Count, m_pCropItemSmall.Count, m_nErroSave));
        }

        public void readCapture(int nDevNo)
        {
            String strMsg = "";

            if (System.IO.File.Exists(JASON_FILE_NAME) == false)
            {
                strMsg = "JASON] NOT EXISTS=" + JASON_FILE_NAME;
                return;
            }
            String tokenName = "";
            try
            {
                String allText = System.IO.File.ReadAllText(JASON_FILE_NAME).Replace("\t", "");
                String allRead = allText.Replace(" ", "");

                JObject jObj = JObject.Parse(allRead);
                Debug.WriteLine("PARSE ALL]" + jObj.Count);

                tokenName = String.Format("Device{0}", nDevNo);
                JToken idToken = jObj[tokenName];
                String mainString = idToken.ToString();
                JObject jDevObj = JObject.Parse(mainString);

                m_AverCap.DeviceType = jDevObj["DeviceType"].ToString();
                m_AverCap.CaptureType = Convert.ToUInt32(jDevObj["CaptureType"].ToString());
                m_AverCap.VideoSource = Convert.ToUInt32(jDevObj["VideoSource"].ToString());
                m_AverCap.AudioSource = Convert.ToUInt32(jDevObj["AudioSource"].ToString());
                m_AverCap.VideoFormat = Convert.ToUInt32(jDevObj["VideoFormat"].ToString());
                m_AverCap.VideoAspectRatio = Convert.ToInt32(jDevObj["VideoAspectRatio"].ToString());
                m_AverCap.VideoOutputFrameRate = Convert.ToUInt32(jDevObj["VideoOutputFrameRate"].ToString());
                m_AverCap.Resolution = Convert.ToUInt32(jDevObj["Resolution"].ToString());
                m_AverCap.IsCustom = 1;
                if (jDevObj["VideoFrameRate"].ToString() == "NO")
                    m_AverCap.IsCustom = 0;
                m_AverCap.ResolutionWidth = Convert.ToUInt32(jDevObj["ResolutionWidth"].ToString());
                m_AverCap.ResolutionHeight = Convert.ToUInt32(jDevObj["ResolutionHeight"].ToString());
                m_AverCap.VideoRenderer = 1;
                if (jDevObj["VideoRenderer"].ToString() == "NO")
                    m_AverCap.VideoRenderer = 0;
                m_AverCap.CaptureNumPerSec = Convert.ToUInt32(jDevObj["CaptureNumPerSec"].ToString());
                m_AverCap.CaptureFileType = jDevObj["CaptureFileType"].ToString();
                m_AverCap.IsStreamView = false;
                if (jDevObj["IsStreamView"].ToString() == "YES")
                    m_AverCap.IsStreamView = true;
            }
            catch (Exception ex)
            {
                strMsg = "MAIN READ FAILED=" + tokenName + ", ERROR=" + ex.Message;
                Debug.WriteLine(tokenName);
            }
        }
    }

    public class JasonCommon
    {
        public int NormalMinWidth { get; set; }
        public int Device { get; set; }
        public bool CaptureEnable { get; set; }
        public bool OcrEnable { get; set; }
        public int ThreadWait { get; set; }
    }

    public class JasonAverMedia
    {
        public String DeviceType { get; set; }  // "DeviceType":"HD",
        public uint CaptureType { get; set; } // "CaptureType":2,
        public uint VideoSource { get; set; }     // "VideoSource":4,
        public uint AudioSource { get; set; } // "AudioSource":8,
        public uint VideoFormat { get; set; } // "VideoFormat":0,
        public int VideoAspectRatio { get; set; } // "VideoAspectRatio":1,
        public uint VideoFrameRate { get; set; } // "VideoFrameRate":6000,
        public uint VideoOutputFrameRate { get; set; } // "VideoOutputFrameRate":600,
        public uint Resolution { get; set; } // "Resolution":7,
        public int IsCustom { get; set; } // "IsCustom":"NO",
        public uint ResolutionWidth { get; set; } // "ResolutionWidth":0,
        public uint ResolutionHeight { get; set; } // "ResolutionHeight":0,
        public int VideoRenderer { get; set; } // "VideoRenderer":"NO",
        public uint CaptureNumPerSec { get; set; } // "CaptureNumPerSec":4,
        public String CaptureFileType { get; set; }  // "CaptureFileType":"BMP",
        public bool IsStreamView { get; set; } // "IsStreamView":"YES",
    }
}
