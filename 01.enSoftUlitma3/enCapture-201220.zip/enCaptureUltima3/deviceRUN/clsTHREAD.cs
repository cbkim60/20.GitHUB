﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Threading;
using System.Diagnostics;

namespace enCaptureUltima3.deviceRUN
{
    class clsTHREAD
    {
        Thread m_pThread;
        public capsuleInfo m_pCapsuleInfo = new capsuleInfo();

        public clsTHREAD(int nDevNo, enCaptureUltima3.ultima2View userControl)
        {
            //m_pAVER = new averRUN(nDevNo);
            m_pCapsuleInfo.initCapsule(nDevNo, userControl);
        }

        public void runAgent()
        {
            m_pThread = new Thread(threadRun);
            m_pThread.Start();
        }

        public void stopAgent()
        {
            try
            {
                //m_pAVER.DeleteCaptureDevice();
                //m_pOpenCV.closeEngine();
                Thread.Sleep(100);
                if (m_pThread != null)
                    m_pThread.Abort();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("!!!!!!!!!!!! ERROR HANDLING:" + ex.Message);
            }
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        // THREAD
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////
        protected void threadRun()
        {
            int nWait = 300;
            m_pCapsuleInfo.initConfig();
            nWait = m_pCapsuleInfo.m_pJASON.m_COMMON.ThreadWait;
            if ((nWait < 100) || (nWait > 1200))
                nWait = 300;
            //Debug.WriteLine("CAPTURE-NAME]" + m_pCapsuleInfo.m_pOCR)
            while(true)
            {
                Thread.Sleep(nWait);
                m_pCapsuleInfo.DoOCR();
            }
        }
    }
}
