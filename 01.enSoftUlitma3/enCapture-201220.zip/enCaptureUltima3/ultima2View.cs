﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace enCaptureUltima3
{
    public partial class ultima2View : UserControl
    {
        public ultima2View()
        {
            InitializeComponent();
        }

        public void setResult(int LineNo, List<String> pData)
        {
            switch(LineNo)
            {
                case 0:
                    ln1_AutoIdle.Text = pData[0];
                    ln1_PPID.Text = pData[1];
                    break;
            }
        }
    }
}
