﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using enUltima3Capture;
using System.Windows.Forms;
using System.Diagnostics;

namespace enCaptureUltima3.deviceRUN
{
    class capsuleInfo
    {
        public clsJASON m_pJASON = new clsJASON();
        public enUltima3Capture.OcrUltima3 m_pOCR = new OcrUltima3();
        public enAverCap m_pAverDevice;

        public List<jasonOcrRect> m_pOcrRUN;

        private int m_nDeviceNo = 0;
        private enCaptureUltima3.ultima2View m_pUserControl;

        private String m_strCaptureName = "";
        private int m_nEdgeHour = -1;

        private int m_nRunSeq = 0;
        private int LOG_RUN_MINUTES = DateTime.Now.Minute / 5;
        private List<int> ElapsedList = new List<int>();

        public event EventHandler<clsEventArgs> ThreadEvent = (s, e) => { };

        public void initCapsule(int devNo, enCaptureUltima3.ultima2View userControl)
        {
            m_nDeviceNo = devNo;
            m_pUserControl = userControl;
            m_strCaptureName = clsLOG.getCapturePath();
            m_strCaptureName += String.Format("cab{0}.bmp", devNo);
            m_pAverDevice = new enAverCap(devNo);
        }

        public void initConfig()
        {
            m_pJASON.readMain();
            m_pJASON.readOCR();
            m_pJASON.readCapture(m_nDeviceNo);

            m_pAverDevice.initConfig();
            m_pAverDevice.m_strCaptureName = clsLOG.getCapturePath();
        }

        public void writeLog(String strMsg)
        {

        }

        public void DoOCR()
        {
            //Debug.WriteLine("--->FILE]" + m_strCaptureName);
            if (System.IO.File.Exists(m_strCaptureName) == false)
            {
                m_pUserControl.lblRUN.Text = "NO FILE";
                return;
            }
            if(m_nEdgeHour != DateTime.Now.Hour)
            {
                m_nEdgeHour = DateTime.Now.Hour;
                m_pOCR.findEdge(m_strCaptureName);
            }
            if (m_pOCR.m_bBasePointFound == false)
            {
                ThreadEvent(this, new clsEventArgs(m_nDeviceNo, 0, "", "EDGE no Found"));
                return;
            }
            int nReqWidth = m_pJASON.m_RectNormal.Width;
            int nReqHeight = m_pJASON.m_RectNormal.Height;
            if (m_pOCR.m_pBasePoint.X > 200)
            {
                m_pOcrRUN = m_pJASON.m_pCropItemNormal;
            }
            else
            {
                m_pOcrRUN = m_pJASON.m_pCropItemSmall;
                nReqWidth = m_pJASON.m_RectSmall.Width;
                nReqHeight = m_pJASON.m_RectSmall.Height;
                Debug.WriteLine("############ SMALL OBJECT]" + nReqWidth + ", BASE=" + m_pOCR.m_pBasePoint.X);
            }
            m_pOCR.OcrDo(m_strCaptureName, (Object)m_pOcrRUN, nReqWidth, nReqHeight);
            if (m_pOCR.m_bOcrResult == true)
            {
                m_pUserControl.picSHOW.Image = m_pOCR.m_ImgGray;
                ThreadEvent(this, new clsEventArgs(m_nDeviceNo, 0, m_pOCR.m_OCR_ERROR, ""));
            }
        }

        public void DoNormal()
        {
            bool bNextRun = true;
            String runMesg = "";
            System.Diagnostics.Stopwatch sw = new Stopwatch();
            sw.Start();
            if (m_pJASON.m_COMMON.CaptureEnable == true)
            {
                if(m_pAverDevice.m_bInitFinished == false)
                {
                    runMesg = m_pAverDevice.averInit();
                    if (runMesg.Length > 0)
                        ThreadEvent(this, new clsEventArgs(m_nDeviceNo, 1, "", runMesg));
                    if (m_pAverDevice.m_bInitFinished == true)
                        m_strCaptureName = m_pAverDevice.m_strCatpureFileName;
                    return;
                }
                bNextRun = m_pAverDevice.captureSingleImage(false);
                if(bNextRun == false)
                {
                    sw.Stop();
                    runMesg = "Fail to capture";
                    clsLOG.writeLogDevice(m_nDeviceNo, runMesg);
                    ThreadEvent(this, new clsEventArgs(m_nDeviceNo, 1, "", runMesg));
                    makeElapsedLog((int)sw.ElapsedMilliseconds);
                    return;
                }
                m_nRunSeq++;
                if(m_nRunSeq > 8)
                {
                    m_nRunSeq = 0;
                    m_pAverDevice.getVideoInform();
                    ThreadEvent(this, new clsEventArgs(m_nDeviceNo, 1, "", m_pAverDevice.RUN_MSG_CAPTION));
                }
            }

            if (m_pJASON.m_COMMON.OcrEnable == true)
            {
                if(System.IO.File.Exists(m_strCaptureName) == false)
                {
                    sw.Stop();
                    runMesg = "Fail to find capture file=" + m_strCaptureName;
                    clsLOG.writeLogDevice(m_nDeviceNo, runMesg);
                    ThreadEvent(this, new clsEventArgs(m_nDeviceNo, 1, "", runMesg));
                    makeElapsedLog((int)sw.ElapsedMilliseconds);
                    System.Threading.Thread.Sleep(500);
                    return;
                }
                DoOCR();
            }
        }

        private void makeElapsedLog(int nElapsed)
        {
            String strMsg = "";

            ElapsedList.Add(nElapsed);
            DateTime dtNow = DateTime.Now;
            if (((dtNow.Minute / 5) != LOG_RUN_MINUTES) && (ElapsedList.Count > 3))
            {
                LOG_RUN_MINUTES = dtNow.Minute / 5;
                int nMin = 1000000, nMax = 0, nTotal = 0;
                foreach (int nVal in ElapsedList)
                {
                    if (nMin > nVal)
                        nMin = nVal;
                    if (nMax < nVal)
                        nMax = nVal;
                    nTotal += nVal;
                }
                strMsg = String.Format("{0}\t{1}\t{2}\t{3}\t{4}",
                    ElapsedList, ElapsedList.Count, (int)(nTotal / ElapsedList.Count), nMin, nMax);

                ElapsedList.Clear();
            }
        }
    }

    public class clsEventArgs : EventArgs
    {
        public int DevNo { get; private set; }
        public String MyWorkResult { get; private set; }
        public String ErrorMsg { get; private set; }
        public int Type { get; private set; }
        public clsEventArgs(int devNo, int reQype, String errMsg, String parseResult)
        { DevNo = devNo; MyWorkResult = parseResult; ErrorMsg = errMsg; Type = reQype; }
    }
}
