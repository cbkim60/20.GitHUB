﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AVerCapSDKDemo;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace enCaptureUltima3.deviceRUN
{
    class enAverCap
    {
        public PictureBox m_PicStream;

        private int m_nRunDevice = 0;
        private clsJASON m_ConfigDevice = new clsJASON();

        public int m_nInitStep = 0;
        public String m_strLogName = "";
        public String m_strCaptureName = "";
        public String m_strCatpureFileName = "";
        public String m_strDeviceName = "";

        public RECT m_rectPICTURE = new RECT();

        public IntPtr m_PictureHandle = (IntPtr)0;

        public IntPtr m_hCaptureDevice = new IntPtr();
        public DEMOSTATE m_DemoState = DEMOSTATE.DEMO_STATE_STOP;
        public bool m_bIsStartStreaming = false;
        public uint m_uCaptureType = 0;
        public uint m_uCurrentCardType = (uint)CARDTYPE.CARDTYPE_NULL;
        private int m_iCurrentDeviceIndex = 0;

        private CAPTURE_IMAGE_INFO m_CaptureImageInfo = new CAPTURE_IMAGE_INFO();

        public bool m_bInitEnable = true;
        public bool m_bInitFinished = false;
        public bool m_bCallBackNeed = false;
        public bool m_bCaptureCheck = false;
        public bool m_bCaptureRun = false;

        public String MSG_STEP = "";
        public String MSG_RUN = "";
        public String MSG_ERR = "";

        // CAPTION INFO
        public String RUN_MSG_CAPTION = "";

        private NOTIFYEVENTCALLBACK m_NotifyEventCallback = new NOTIFYEVENTCALLBACK(NotifyEventCallback);

        public int m_nPicPaintRun = 0;
        public int m_nPicPaintSet = 0;

        public enAverCap(int devNo)
        {
            m_nRunDevice = devNo;
        }

        public void initConfig()
        {
            m_ConfigDevice.readCapture(m_nRunDevice);
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /// INITIAL FUNCTIONS
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        public String averInit()
        {
            String strMsg = "";

            MSG_ERR = "";
            switch (m_nInitStep)
            {
                case 0:
                    strMsg = initCheckDevice();
                    if (strMsg.Length > 0)
                    {
                        System.Threading.Thread.Sleep(3000);
                        return (strMsg);
                    }
                    break;
                case 1:
                    getDeviceName();
                    strMsg = String.Format("CAPTURE={0}", m_strCaptureName);
                    clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                    break;
                case 2:
                    selectDevice();
                    if (MSG_ERR.Length > 0)
                    {
                        strMsg = MSG_ERR;
                        System.Threading.Thread.Sleep(3000);
                        return (strMsg);
                    }
                    break;
                case 3:
                    setDevice();
                    break;
                case 4:
                    startStreaming();
                    if (m_bIsStartStreaming == false)
                    {
                        strMsg = "Streaming FAILED";
                        return (strMsg);
                    }
                    break;
                case 5:
                    m_bCaptureCheck = true;
                    captureSingleImage(true);
                    m_bInitFinished = true;
                    break;
            }

            if (strMsg.Length == 0)
                strMsg = String.Format("INIT STEP={0}", m_nInitStep);
            m_nInitStep++;

            return (strMsg);
        }

        private String initCheckDevice()
        {
            uint dwGetVal = 0;
            String strRun = "";

            if (AVerCapAPI.AVerGetDeviceNum(ref dwGetVal) != (int)ERRORCODE.CAP_EC_SUCCESS)
            {
                strRun = "Can't get the number of devices.";
                return (strRun);
            }
            if (dwGetVal == 0)
            {
                strRun = "NO capture DEVICE";
                return (strRun);
            }
            strRun = String.Format("DEVICE COUNT={0}", dwGetVal);
            clsLOG.writeLogDevice(m_nRunDevice, strRun);
            if (m_nRunDevice >= dwGetVal)
            {
                strRun = String.Format("NO valid Device={0} in {1}", m_nRunDevice, dwGetVal);
                return (strRun);
            }

            return ("");
        }

        private void getDeviceName()
        {
            StringBuilder wszDeviceName = new StringBuilder("", 50);
            AVerCapAPI.AVerGetDeviceName((uint)m_nRunDevice, wszDeviceName);
            m_strDeviceName = wszDeviceName.ToString();

            // set CAPTURE NAME
            m_CaptureImageInfo.dwVersion = 1;
            m_CaptureImageInfo.dwImageType = 1;
            m_CaptureImageInfo.bOverlayMix = 1;
            m_strCaptureName += String.Format("cap{0}", m_nRunDevice);
            m_strCatpureFileName = m_strCaptureName;
            if (m_ConfigDevice.m_AverCap.CaptureFileType.IndexOf("JPG") >= 0)
            {
                m_strCatpureFileName += ".jpg";
                m_CaptureImageInfo.dwImageType = (uint)IMAGETYPE.IMAGETYPE_JPG;
            }
            else if (m_ConfigDevice.m_AverCap.CaptureFileType.IndexOf("PNG") >= 0)
            {
                m_strCatpureFileName += ".png";
                m_CaptureImageInfo.dwImageType = (uint)IMAGETYPE.IMAGETYPE_PNG;
            }
            else if (m_ConfigDevice.m_AverCap.CaptureFileType.IndexOf("TIFF") >= 0)
            {
                m_strCatpureFileName += ".tiff";
                m_CaptureImageInfo.dwImageType = (uint)IMAGETYPE.IMAGETYPE_TIFF;
            }
            else
            {
                m_strCatpureFileName += ".bmp";
                m_CaptureImageInfo.dwImageType = (uint)IMAGETYPE.IMAGETYPE_BMP;
            }
            m_CaptureImageInfo.lpFileName = m_strCaptureName;
            //m_CaptureImageInfo.lpFileName = m_strCatpureFileName;

            String strMsg;
            strMsg = String.Format("getDeviceName()] CAPTURE NAME={0} TYPE={1}", m_CaptureImageInfo.lpFileName, m_CaptureImageInfo.dwImageType);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);
        }

        private int selectDevice()
        {
            m_DemoState = DEMOSTATE.DEMO_STATE_STOP;

            int iTempIndex = m_nRunDevice;
            int iTempdeviceType = -1; 
            if ((m_ConfigDevice.m_AverCap.DeviceType.IndexOf("SDdevice") >= 0) || (m_ConfigDevice.m_AverCap.DeviceType.IndexOf("SD") >= 0))
                iTempdeviceType = (int)CAPTURETYPE.CAPTURETYPE_SD;
            else
                iTempdeviceType = (int)CAPTURETYPE.CAPTURETYPE_HD;

            if (m_hCaptureDevice != (IntPtr)0)
            {
                DeleteCaptureDevice();
            }

            m_uCaptureType = 0;
            m_iCurrentDeviceIndex = -1;

            int iRetVal = 0;
            IntPtr picView = m_PictureHandle;
            if (m_ConfigDevice.m_AverCap.IsStreamView == false) 
                 picView = (IntPtr)0;
            if (iTempdeviceType == (int)CAPTURETYPE.CAPTURETYPE_SD)
            {
                iRetVal = AVerCapAPI.AVerCreateCaptureObjectEx((uint)iTempIndex, (uint)CAPTURETYPE.CAPTURETYPE_SD, picView, ref m_hCaptureDevice);
            }
            else
            {
                iRetVal = AVerCapAPI.AVerCreateCaptureObjectEx((uint)iTempIndex, (uint)CAPTURETYPE.CAPTURETYPE_HD, picView, ref m_hCaptureDevice);
            }
            switch (iRetVal)
            {
                case (int)ERRORCODE.CAP_EC_SUCCESS:
                    break;
                case (int)ERRORCODE.CAP_EC_DEVICE_IN_USE:
                    MSG_ERR = "The capture device has already been used";
                    return -1;
                default:
                    MSG_ERR = "Can't initialize the capture device";
                    return -1;
            }
            m_iCurrentDeviceIndex = iTempIndex;

            String strMsg;
            strMsg = String.Format("selectDevice()={0} RESULT={1} m_iCurrentDeviceIndex={2}", iTempdeviceType, iRetVal, m_iCurrentDeviceIndex);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);

            if (m_uCaptureType == 0)
            {
                if (iTempdeviceType == (int)CAPTURETYPE.CAPTURETYPE_SD)
                {
                    m_uCaptureType = (uint)CAPTURETYPE.CAPTURETYPE_SD;
                }
                else
                {
                    m_uCaptureType = (uint)CAPTURETYPE.CAPTURETYPE_HD;
                }
                m_uCurrentCardType = GetCurrentCardType(m_iCurrentDeviceIndex);
                strMsg = String.Format("GetCurrentCardType()] m_uCurrentCardType={0} ", m_uCurrentCardType);
                clsLOG.writeLogDevice(m_nRunDevice, strMsg);
            }

            return 0;
        }

        private void setDevice()
        {
            String strMsg;

            uint dwCardType = 0;
            AVerCapAPI.AVerGetDeviceType((uint)m_nRunDevice, ref dwCardType);
            strMsg = String.Format("{0}] CARD TYPE={1}", m_nRunDevice, dwCardType);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);

            uint dwVideoSource = 3;//hdmi
            uint dwFormat = 0;
            dwVideoSource = m_ConfigDevice.m_AverCap.VideoSource;
            FRAMERATE_RANGE_INFO FrameRateRangeInfo = new FRAMERATE_RANGE_INFO();
            FrameRateRangeInfo.dwVersion = 1;
            int hr = AVerCapAPI.AVerGetVideoInputFrameRateRangeSupported(m_hCaptureDevice, dwVideoSource, dwFormat, 0, 0, ref FrameRateRangeInfo);
            strMsg = String.Format("setDevice-AVerGetVideoInputFrameRateRangeSupported()={0} RESULT={1} ", FrameRateRangeInfo.bRange, hr);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);
            bool bIsRangeFramerate = false;
            if (hr == (int)ERRORCODE.CAP_EC_SUCCESS)
            {
                if (FrameRateRangeInfo.bRange == 0)
                    bIsRangeFramerate = false;
                else
                    bIsRangeFramerate = true;
            }

            int apiResult = AVerCapAPI.AVerSetVideoSource(m_hCaptureDevice, m_ConfigDevice.m_AverCap.VideoSource);
            strMsg = String.Format("AVerSetVideoSource()={0} RESULT={1} ", m_ConfigDevice.m_AverCap.VideoSource, apiResult);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);

            apiResult = AVerCapAPI.AVerSetAudioSource(m_hCaptureDevice, m_ConfigDevice.m_AverCap.AudioSource);
            strMsg = String.Format("AVerSetAudioSource()={0} RESULT={1} ", m_ConfigDevice.m_AverCap.AudioSource, apiResult);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);

            apiResult = AVerCapAPI.AVerSetVideoFormat(m_hCaptureDevice, m_ConfigDevice.m_AverCap.VideoFormat);
            strMsg = String.Format("AVerSetVideoFormat()={0} RESULT={1} ", m_ConfigDevice.m_AverCap.VideoFormat, apiResult);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);

            int keepAspectRatio = 1;
            keepAspectRatio = m_ConfigDevice.m_AverCap.VideoAspectRatio;
            AVerCapAPI.AVerSetMaintainAspectRatioEnabled(m_hCaptureDevice, keepAspectRatio);

            //apiResult = AVerCapAPI.AVerSetVideoInputFrameRate(m_hCaptureDevice, EN_CONFIG.m_dwVideoFrameRate);
            //strMsg = String.Format("AVerSetVideoInputFrameRate()={0} RESULT={1} ", EN_CONFIG.m_dwVideoFrameRate, apiResult);
            //clsLOG.writeLogDevice(m_nRunDevice, strMsg);
            uint uVideoSource = 0;
            uint uVideoFormat = 0;
            AVerCapAPI.AVerGetVideoSource(m_hCaptureDevice, ref uVideoSource);
            AVerCapAPI.AVerGetVideoFormat(m_hCaptureDevice, ref uVideoFormat);
            uint setFrameRate = 0;
            uint VideoSource = m_ConfigDevice.m_AverCap.VideoSource;
            bool bOutputFrameRateSet = false;

            setFrameRate = m_ConfigDevice.m_AverCap.VideoOutputFrameRate;
            if (setFrameRate >= 500)
            {
                apiResult = AVerCapAPI.AVerSetVideoOutputFrameRate(m_hCaptureDevice, setFrameRate);
                if (apiResult == (int)ERRORCODE.CAP_EC_SUCCESS)
                {
                    strMsg = String.Format("AVerSetVideoOutputFrameRate()={0} RESULT={1} ", setFrameRate, apiResult);
                    clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                    //bOutputFrameRateSet = true;
                }
            }

            if (bOutputFrameRateSet == false)
            {
                if (bIsRangeFramerate)
                {
                    uint uFrameRate = 0;
                    int ir = AVerCapAPI.AVerGetVideoInputFrameRate(m_hCaptureDevice, ref uFrameRate);
                    if (ir != (int)ERRORCODE.CAP_EC_SUCCESS)
                    {
                        strMsg = String.Format("AVerGetVideoInputFrameRate()={0} RESULT={1} ", VideoSource, ir);
                        clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                    }
                    else
                    {
                        strMsg = String.Format("VALID AVerGetVideoInputFrameRate()={0} FRAME={1} ", VideoSource, uFrameRate);
                        clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                        setFrameRate = uFrameRate;

                        ir = AVerCapAPI.AVerSetVideoInputFrameRate(m_hCaptureDevice, setFrameRate);
                        if (ir != (int)ERRORCODE.CAP_EC_SUCCESS)
                        {
                            strMsg = String.Format("AVerSetVideoInputFrameRate()={0} RESULT={1} ", VideoSource, ir);
                            if (ir == (int)ERRORCODE.CAP_EC_INVALID_PARAM)
                                strMsg = String.Format("AVerSetVideoInputFrameRate()={0} RESULT={1} INVALID FRAMERATE", VideoSource, ir);
                        }
                        else
                        {
                            strMsg = String.Format("AVerSetVideoInputFrameRate()={0} SUCCESS={1} ", VideoSource, setFrameRate);
                        }
                        clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                    }

                }
                else
                {
                    uint uNum = 0;
                    int lr = 0;

                    VIDEO_RESOLUTION frVideoRes = new VIDEO_RESOLUTION();
                    frVideoRes.dwVersion = 1;
                    AVerCapAPI.AVerGetVideoResolutionEx(m_hCaptureDevice, ref frVideoRes);
                    lr = AVerCapAPI.AVerGetVideoInputFrameRateSupportedEx(m_hCaptureDevice, uVideoSource, uVideoFormat, frVideoRes.dwVideoResolution, null, ref uNum);
                    uint[] pdwFrameRateSupported = new uint[uNum];
                    if (lr != (int)ERRORCODE.CAP_EC_SUCCESS)
                    {
                        if (lr == (int)ERRORCODE.CAP_EC_NOT_SUPPORTED)
                        {
                            strMsg = String.Format("AVerGetVideoInputFrameRateSupportedEx()={0} RESULT={1} ", frVideoRes.dwVideoResolution, lr);
                        }
                        else
                            strMsg = String.Format("AVerGetVideoInputFrameRateSupportedEx()={0} RESULT={1} ", frVideoRes.dwVideoResolution, lr);
                        clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                    }
                    else
                    {
                        lr = AVerCapAPI.AVerGetVideoInputFrameRateSupportedEx(m_hCaptureDevice, uVideoSource, uVideoFormat, frVideoRes.dwVideoResolution, pdwFrameRateSupported, ref uNum);
                        if (lr != (int)ERRORCODE.CAP_EC_SUCCESS)
                        {
                            strMsg = String.Format("AVerGetVideoInputFrameRateSupportedEx()={0} RESULT={1} ", frVideoRes.dwVideoResolution, lr);
                            clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                        }
                        else
                        {
                            setFrameRate = 100000000;
                            for (int i = 0; i < uNum; i++)
                            {
                                if (pdwFrameRateSupported[i] < setFrameRate)
                                    setFrameRate = pdwFrameRateSupported[i];
                            }
                            lr = AVerCapAPI.AVerSetVideoInputFrameRate(m_hCaptureDevice, setFrameRate);
                            strMsg = String.Format("AVerSetVideoInputFrameRate()={0} SUCCESS={1} ", VideoSource, setFrameRate);
                            clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                        }
                    }
                }
            }

            VIDEO_RESOLUTION VideoResolution = new VIDEO_RESOLUTION();
            VideoResolution.dwVersion = 1;
            VideoResolution.dwVideoResolution = m_ConfigDevice.m_AverCap.Resolution; 
            VideoResolution.dwWidth = m_ConfigDevice.m_AverCap.ResolutionWidth;
            VideoResolution.dwHeight = m_ConfigDevice.m_AverCap.ResolutionHeight;
            VideoResolution.bCustom = m_ConfigDevice.m_AverCap.IsCustom;
            apiResult = AVerCapAPI.AVerSetVideoResolutionEx(m_hCaptureDevice, ref VideoResolution);
            strMsg = String.Format("AVerSetVideoResolutionEx()={0} RESULT={1} ",
                m_ConfigDevice.m_AverCap.Resolution, apiResult);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);

            // disable audio
            int audioEnable = 0;
            AVerCapAPI.AVerSetAudioPreviewEnabled(m_hCaptureDevice, audioEnable);

            // CHECK CLIP

            m_bCallBackNeed = true;
        }

        private int startStreaming()
        {
            if (m_ConfigDevice.m_AverCap.VideoRenderer != 0)
                AVerCapAPI.AVerSetVideoRenderer(m_hCaptureDevice, (uint)VIDEORENDERER.VIDEORENDERER_EVR);

            GCHandle gchThis = GCHandle.Alloc(this);
            AVerCapAPI.AVerSetEventCallback(m_hCaptureDevice, m_NotifyEventCallback, 0, GCHandle.ToIntPtr(gchThis));

            int apiResult = AVerCapAPI.AVerStartStreaming(m_hCaptureDevice);
            if (apiResult != (int)ERRORCODE.CAP_EC_SUCCESS)
            {
                //MessageBox.Show("Can't start streaming", "AVer Capture SDK");
                MSG_ERR = String.Format("[{0}]Can't start streaming", apiResult);
                return -1;
            }

            changePictureSize();
            m_bIsStartStreaming = true;
            UpdateDemoState(DEMOSTATE.DEMO_STATE_PREVIEW, true);
            String strMsg = String.Format("startStreaming()={0} RESULT={1}",
                m_ConfigDevice.m_AverCap.VideoRenderer, apiResult);
            clsLOG.writeLogDevice(m_nRunDevice, strMsg);
            return 0;
        }

        public bool captureSingleImage(bool bCheck)
        {
            String strMsg;

            m_CaptureImageInfo.dwCaptureType = (uint)CT_SEQUENCE.CT_SEQUENCE_FRAME;
            //m_CaptureImageInfo.bOverlayMix = 1;
            m_CaptureImageInfo.bOverlayMix = 0;
            m_CaptureImageInfo.dwDurationMode = (uint)DURATIONMODE.DURATION_COUNT;
            //m_CaptureImageInfo.dwDurationMode = (uint)DURATIONMODE.DURATION_TIME;
            m_CaptureImageInfo.dwDuration = uint.MaxValue;

            m_CaptureImageInfo.rcCapRect.Left = 0;
            m_CaptureImageInfo.rcCapRect.Right = 0;
            m_CaptureImageInfo.rcCapRect.Top = 0;
            m_CaptureImageInfo.rcCapRect.Bottom = 0;
            m_CaptureImageInfo.dwDurationMode = (uint)DURATIONMODE.DURATION_COUNT;
            m_CaptureImageInfo.dwDuration = 1;
            m_CaptureImageInfo.dwVersion = 1;

            int iRetVal = AVerCapAPI.AVerCaptureImageStart(m_hCaptureDevice, ref m_CaptureImageInfo);
            strMsg = "";
            bool bCaptured = false;
            if (iRetVal != 0)
            {
                if (iRetVal == (int)ERRORCODE.CAP_EC_HDCP_PROTECTED_CONTENT)
                    strMsg = String.Format("setCapture()] The program content is protected={0} ", iRetVal);
                else
                    strMsg = String.Format("setCapture()] The width and height of capture area are not a multiple of 2 or out of range={0} ", iRetVal);
            }
            else
            {
                strMsg = String.Format("setCapture()] STARTED={0} ", iRetVal);
                if (bCheck == true)
                {
                    m_bCaptureRun = true;
                    strMsg += String.Format(" FILE1={0} FILE2={1}", m_CaptureImageInfo.lpFileName, m_strCatpureFileName);
                }
                bCaptured = true;
                //AVerCapAPI.AVerCaptureImageStop(m_hCaptureDevice, 0);
            }
            if (bCheck == true)
                clsLOG.writeLogDevice(m_nRunDevice, strMsg);
            return bCaptured;
        }



        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /// LOCAL AUXILARY FUNCTIONS
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        public uint GetCurrentCardType(int iCurrentDeviceIndex)
        {
            if (iCurrentDeviceIndex < 0)
                return (uint)CARDTYPE.CARDTYPE_NULL;
            uint DeviceType = 0;

            AVerCapAPI.AVerGetDeviceType((uint)iCurrentDeviceIndex, ref DeviceType);
            return DeviceType;
        }

        public void changePictureSize()
        {
            RECT RectClient = new RECT();
            RectClient.Left = 0;
            RectClient.Top = 0;
            RectClient.Right = m_PicStream.Width;
            RectClient.Bottom = m_PicStream.Height;
            AVerCapAPI.AVerSetVideoWindowPosition(m_hCaptureDevice, RectClient);
        }

        public void UpdateDemoState(DEMOSTATE DemoState, bool bSwitch)
        {
            if (DemoState == DEMOSTATE.DEMO_STATE_STOP)
            {
                m_DemoState = DEMOSTATE.DEMO_STATE_STOP;
            }
            if (bSwitch)
            {
                m_DemoState = m_DemoState | DemoState;
            }
            else
            {
                m_DemoState = m_DemoState & (~DemoState);
            }
        }

        public void getVideoInform()
        {
            String strMsg = "";
            if ((m_hCaptureDevice == (IntPtr)0) || (m_bIsStartStreaming == false))
            {
                strMsg = "getVideoInform] m_hCaptureDevice NULL or no STREAMING";
                clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                return;
            }
            INPUT_VIDEO_INFO InputVideoInfo = new INPUT_VIDEO_INFO();
            InputVideoInfo.dwVersion = 2;
            int bSignalPresence = 0;

            if ((int)ERRORCODE.CAP_EC_SUCCESS != AVerCapAPI.AVerGetSignalPresence(m_hCaptureDevice, ref bSignalPresence))
            {
                strMsg = "getVideoInform] AVerGetSignalPresence() Can't get signal presence";
                clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                return;
            }
            if ((int)ERRORCODE.CAP_EC_SUCCESS != AVerCapAPI.AVerGetVideoInfo(m_hCaptureDevice, ref InputVideoInfo))
            {
                strMsg = "getVideoInform] AVerGetVideoInfo() Get input video info failed";
                clsLOG.writeLogDevice(m_nRunDevice, strMsg);
                return;
            }
            double dFrameRate = InputVideoInfo.dwFramerate / 100.0;
            uint uWidth = InputVideoInfo.dwWidth;
            uint uHeight = InputVideoInfo.dwHeight;
            RUN_MSG_CAPTION = String.Format("{0}: {1} {2,-4:d}*{3,-4:d}@{4,4:f2}",
                m_nRunDevice, bSignalPresence, uWidth, uHeight, dFrameRate);
            if (InputVideoInfo.bProgressive == 1)
                RUN_MSG_CAPTION += "p";
            else
                RUN_MSG_CAPTION += "i";
        }


        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /// PUBLIC FUNCTIONS
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        public void DeleteCaptureDevice()
        {
            if (m_hCaptureDevice == (IntPtr)0)
                return;
            if (m_bCaptureRun == true)
            {
                AVerCapAPI.AVerCaptureImageStop(m_hCaptureDevice, 0);
                m_bCaptureRun = false;
            }
            if (m_bIsStartStreaming)
            {
                AVerCapAPI.AVerStopStreaming(m_hCaptureDevice);
                m_bIsStartStreaming = false;
            }
            AVerCapAPI.AVerDeleteCaptureObject(m_hCaptureDevice);
            m_hCaptureDevice = (IntPtr)0;
        }





        /////////////////////////////////////////////////////////////////////////////////////////////////////
        /// CALLBACK NOTIFY
        /////////////////////////////////////////////////////////////////////////////////////////////////////
        public static int NotifyEventCallback(uint dwEventCode, IntPtr lpEventData, IntPtr lpUserData)
        {
            switch (dwEventCode)
            {
                case (uint)CAPTUREEVENT.EVENT_CAPTUREIMAGE:
                    {
                        if (lpUserData == null || lpEventData == null)
                            return 0;

                        GCHandle gchThis = GCHandle.FromIntPtr(lpUserData);
                        CAPTUREIMAGE_NOTIFY_INFO CaptureImageNotifyInfo = new CAPTUREIMAGE_NOTIFY_INFO();
                        CaptureImageNotifyInfo = (CAPTUREIMAGE_NOTIFY_INFO)Marshal.PtrToStructure(lpEventData, typeof(CAPTUREIMAGE_NOTIFY_INFO));
                        //if (((Form1)gchThis.Target).m_ShowCaptureImage != null)
                        //    ((Form1)gchThis.Target).m_ShowCaptureImage.ModifyName(ref CaptureImageNotifyInfo);
                    }
                    break;
                case (uint)CAPTUREEVENT.EVENT_CHECKCOPP:
                    {
                        uint plErrorID = (uint)Marshal.ReadInt32(lpEventData);
                        string strErrorID = "";
                        switch (plErrorID)
                        {
                            case (uint)COPPERRCODE.COPP_ERR_UNKNOWN:
                                strErrorID = "COPP_ERR_UNKNOWN";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_NO_COPP_HW:
                                strErrorID = "COPP_ERR_NO_COPP_HW";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_NO_MONITORS_CORRESPOND_TO_DISPLAY_DEVICE:
                                strErrorID = "COPP_ERR_NO_MONITORS_CORRESPOND_TO_DISPLAY_DEVICE";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_CERTIFICATE_CHAIN_FAILED:
                                strErrorID = "COPP_ERR_CERTIFICATE_CHAIN_FAILED";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_STATUS_LINK_LOST:
                                strErrorID = "COPP_ERR_STATUS_LINK_LOST";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_NO_HDCP_PROTECTION_TYPE:
                                strErrorID = "COPP_ERR_NO_HDCP_PROTECTION_TYPE";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_HDCP_REPEATER:
                                strErrorID = "COPP_ERR_HDCP_REPEATER";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_HDCP_PROTECTED_CONTENT:
                                strErrorID = "COPP_ERR_HDCP_PROTECTED_CONTENT";
                                break;
                            case (uint)COPPERRCODE.COPP_ERR_GET_CRL_FAILED:
                                strErrorID = "COPP_ERR_GET_CRL_FAILED";
                                break;
                        }
                        MessageBox.Show(strErrorID);
                    }
                    break;
                default:
                    return 0;
            }
            return 1;
        }
    }
}
