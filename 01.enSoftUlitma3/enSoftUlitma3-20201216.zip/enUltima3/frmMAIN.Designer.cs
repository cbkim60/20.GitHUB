﻿namespace enUltima3Cap
{
    partial class frmMAIN
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMSG = new System.Windows.Forms.Label();
            this.lblRESOLUTION = new System.Windows.Forms.Label();
            this.lblSTEP = new System.Windows.Forms.Label();
            this.picSHOW0 = new System.Windows.Forms.PictureBox();
            this.picSHOW1 = new System.Windows.Forms.PictureBox();
            this.lblDEVICE0 = new System.Windows.Forms.Label();
            this.lblDEVICE1 = new System.Windows.Forms.Label();
            this.picHIDE0 = new System.Windows.Forms.PictureBox();
            this.picHIDE1 = new System.Windows.Forms.PictureBox();
            this.cmbDEVICE = new System.Windows.Forms.ComboBox();
            this.checkVIEW = new System.Windows.Forms.CheckBox();
            this.lbVIEW = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSHOW0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSHOW1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHIDE0)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHIDE1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblMSG
            // 
            this.lblMSG.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblMSG.ForeColor = System.Drawing.Color.Red;
            this.lblMSG.Location = new System.Drawing.Point(366, 13);
            this.lblMSG.Name = "lblMSG";
            this.lblMSG.Size = new System.Drawing.Size(360, 23);
            this.lblMSG.TabIndex = 7;
            this.lblMSG.Text = "label1";
            this.lblMSG.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblRESOLUTION
            // 
            this.lblRESOLUTION.Location = new System.Drawing.Point(159, 13);
            this.lblRESOLUTION.Name = "lblRESOLUTION";
            this.lblRESOLUTION.Size = new System.Drawing.Size(130, 23);
            this.lblRESOLUTION.TabIndex = 6;
            this.lblRESOLUTION.Text = "label1";
            this.lblRESOLUTION.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblSTEP
            // 
            this.lblSTEP.Location = new System.Drawing.Point(12, 13);
            this.lblSTEP.Name = "lblSTEP";
            this.lblSTEP.Size = new System.Drawing.Size(130, 23);
            this.lblSTEP.TabIndex = 5;
            this.lblSTEP.Text = "label1";
            this.lblSTEP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // picSHOW0
            // 
            this.picSHOW0.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.picSHOW0.Location = new System.Drawing.Point(12, 68);
            this.picSHOW0.Name = "picSHOW0";
            this.picSHOW0.Size = new System.Drawing.Size(422, 286);
            this.picSHOW0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSHOW0.TabIndex = 8;
            this.picSHOW0.TabStop = false;
            // 
            // picSHOW1
            // 
            this.picSHOW1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picSHOW1.Location = new System.Drawing.Point(440, 68);
            this.picSHOW1.Name = "picSHOW1";
            this.picSHOW1.Size = new System.Drawing.Size(431, 286);
            this.picSHOW1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSHOW1.TabIndex = 9;
            this.picSHOW1.TabStop = false;
            // 
            // lblDEVICE0
            // 
            this.lblDEVICE0.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblDEVICE0.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblDEVICE0.Location = new System.Drawing.Point(10, 42);
            this.lblDEVICE0.Name = "lblDEVICE0";
            this.lblDEVICE0.Size = new System.Drawing.Size(424, 23);
            this.lblDEVICE0.TabIndex = 10;
            this.lblDEVICE0.Text = "label1";
            this.lblDEVICE0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblDEVICE1
            // 
            this.lblDEVICE1.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblDEVICE1.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblDEVICE1.Location = new System.Drawing.Point(438, 42);
            this.lblDEVICE1.Name = "lblDEVICE1";
            this.lblDEVICE1.Size = new System.Drawing.Size(424, 23);
            this.lblDEVICE1.TabIndex = 11;
            this.lblDEVICE1.Text = "label1";
            this.lblDEVICE1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // picHIDE0
            // 
            this.picHIDE0.Location = new System.Drawing.Point(732, 12);
            this.picHIDE0.Name = "picHIDE0";
            this.picHIDE0.Size = new System.Drawing.Size(51, 27);
            this.picHIDE0.TabIndex = 12;
            this.picHIDE0.TabStop = false;
            // 
            // picHIDE1
            // 
            this.picHIDE1.Location = new System.Drawing.Point(789, 13);
            this.picHIDE1.Name = "picHIDE1";
            this.picHIDE1.Size = new System.Drawing.Size(46, 26);
            this.picHIDE1.TabIndex = 13;
            this.picHIDE1.TabStop = false;
            // 
            // cmbDEVICE
            // 
            this.cmbDEVICE.FormattingEnabled = true;
            this.cmbDEVICE.Location = new System.Drawing.Point(13, 360);
            this.cmbDEVICE.Name = "cmbDEVICE";
            this.cmbDEVICE.Size = new System.Drawing.Size(121, 20);
            this.cmbDEVICE.TabIndex = 14;
            // 
            // checkVIEW
            // 
            this.checkVIEW.AutoSize = true;
            this.checkVIEW.Location = new System.Drawing.Point(141, 363);
            this.checkVIEW.Name = "checkVIEW";
            this.checkVIEW.Size = new System.Drawing.Size(53, 16);
            this.checkVIEW.TabIndex = 15;
            this.checkVIEW.Text = "VIEW";
            this.checkVIEW.UseVisualStyleBackColor = true;
            // 
            // lbVIEW
            // 
            this.lbVIEW.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbVIEW.FormattingEnabled = true;
            this.lbVIEW.ItemHeight = 12;
            this.lbVIEW.Location = new System.Drawing.Point(14, 387);
            this.lbVIEW.Name = "lbVIEW";
            this.lbVIEW.Size = new System.Drawing.Size(857, 280);
            this.lbVIEW.TabIndex = 16;
            // 
            // frmMAIN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(878, 678);
            this.Controls.Add(this.lbVIEW);
            this.Controls.Add(this.checkVIEW);
            this.Controls.Add(this.cmbDEVICE);
            this.Controls.Add(this.picHIDE1);
            this.Controls.Add(this.picHIDE0);
            this.Controls.Add(this.lblDEVICE1);
            this.Controls.Add(this.lblDEVICE0);
            this.Controls.Add(this.picSHOW1);
            this.Controls.Add(this.picSHOW0);
            this.Controls.Add(this.lblMSG);
            this.Controls.Add(this.lblRESOLUTION);
            this.Controls.Add(this.lblSTEP);
            this.Name = "frmMAIN";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.picSHOW0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSHOW1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHIDE0)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHIDE1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMSG;
        private System.Windows.Forms.Label lblRESOLUTION;
        private System.Windows.Forms.Label lblSTEP;
        private System.Windows.Forms.PictureBox picSHOW0;
        private System.Windows.Forms.PictureBox picSHOW1;
        private System.Windows.Forms.Label lblDEVICE0;
        private System.Windows.Forms.Label lblDEVICE1;
        private System.Windows.Forms.PictureBox picHIDE0;
        private System.Windows.Forms.PictureBox picHIDE1;
        private System.Windows.Forms.ComboBox cmbDEVICE;
        private System.Windows.Forms.CheckBox checkVIEW;
        private System.Windows.Forms.ListBox lbVIEW;
    }
}

