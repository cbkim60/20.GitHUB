﻿using enUltima3Capture;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using OpenCvSharp;
using OpenCvSharp.Extensions;
using OpenCvSharp.ML;
using System.Diagnostics;

namespace enCaptureAnal
{
    public partial class frmANAL : Form
    {
        private System.Drawing.Size picSize = new System.Drawing.Size();
        private String m_pOrgFileName = "";
        private OcrUltima3 m_OcrRun = new OcrUltima3();
        private knOCR m_pKnOcr = new knOCR();
        private bool m_bOcrLearn = false;

        private List<rawPicData> m_ListPicSave = new List<rawPicData>();
        private List<jasonOcrRect> m_ListJason = new List<jasonOcrRect>();

        private String baseSaveFolder = @".\picSave\";
        private const String baseOcrFolder = @".\picOCR\";
        private const String ocrFolderDigit = @"D\";
        private const String ocrFolderDigit2 = @"D2\";
        private const String ocrFolderText = @"T\";
        private const String ocrFolderSymbol = @"S\";

        private const String m_StringLocalJasonFile = @".\jasonOcr.txt";

        ////////////////////////////////////////////////////////////////////////////////////
        /// Draw Rectangle on PictureBox
        /// ////////////////////////////////////////////////////////////////////////////////////
        // https://rocabilly.tistory.com/117
        // https://csmemory.tistory.com/entry/%EC%82%AC%EA%B0%81%ED%98%95-%EC%98%81%EC%97%AD-%EA%B7%B8%EB%A6%AC%EA%B8%B0
        private bool bLeftButtonDown = false;
        private System.Drawing.Point ClickPoint = new System.Drawing.Point();
        private System.Drawing.Point CurrentTopLeft = new System.Drawing.Point();
        private System.Drawing.Point CurrentBottomRight = new System.Drawing.Point();
        private Pen MyPen;
        private Graphics g;


        public frmANAL()
        {
            InitializeComponent();
        }

        private void frmANAL_Load(object sender, EventArgs e)
        {
            String checkFolder = "";
            for (int n = 0; n < 6; n++)
            {
                checkFolder = "";
                switch (n)
                {
                    case 0: checkFolder = baseSaveFolder; break;
                    case 1: checkFolder = baseOcrFolder; break;
                    case 2: checkFolder = baseOcrFolder + ocrFolderDigit; break;
                    case 3: checkFolder = baseOcrFolder + ocrFolderDigit2; break;
                    case 4: checkFolder = baseOcrFolder + ocrFolderText; break;
                    case 5: checkFolder = baseOcrFolder + ocrFolderSymbol; break;
                }
                if (checkFolder.Length > 3)
                {
                    if (System.IO.Directory.Exists(checkFolder) == false)
                        System.IO.Directory.CreateDirectory(checkFolder);
                }
            }

            MyPen = new Pen(Color.Red, 2);
            MyPen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;

            cmbSELECT.Items.Add("ORG");
            cmbSELECT.Items.Add("GRAY");
            cmbSELECT.Items.Add("CONTOUR");
            cmbSELECT.Items.Add("DIST");
            cmbSELECT.SelectedIndexChanged += CmbSELECT_SelectedIndexChanged;

            cmbTextType.Items.Add("DIGIT");
            cmbTextType.Items.Add("SYMBOL");
            cmbTextType.Items.Add("FLOAT");
            cmbTextType.Items.Add("MATH");
            cmbTextType.Items.Add("TIME");
            cmbTextType.Items.Add("TEXT");
            cmbTextType.SelectedIndex = 0;

            btnOpen.Click += BtnOpen_Click;
            btnSelect.Click += BtnSelect_Click;
            btnRUN.Click += BtnRUN_Click;
            btnSelect.Enabled = false;
            btnRUN.Enabled = false;

            btnKeep.Click += BtnKeep_Click;
            btnPicSave.Click += BtnPicSave_Click;

            btnLearnOCR.Click += BtnLearnOCR_Click;
            btnViewRect.Click += BtnViewRect_Click;
            btnDoOCR.Click += BtnDoOCR_Click;
            btnViewRect.Enabled = false;
            btnDoOCR.Enabled = false;

            btnOcrKeep.Click += BtnOcrKeep_Click;
            btnSaveJason.Click += BtnSaveJason_Click;
            btnOcrKeep.Enabled = false;
            btnSaveJason.Enabled = false;

            btnFileOCR.Click += BtnFileOCR_Click;
            btnFileOCR.Enabled = false;

            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.MouseClick += PictureBox1_MouseClick;
            pictureBox1.MouseDown += PictureBox1_MouseDown;
            pictureBox1.MouseUp += PictureBox1_MouseUp;
            pictureBox1.MouseMove += PictureBox1_MouseMove;
            pictureBox1.MouseDoubleClick += PictureBox1_MouseDoubleClick;

            picSelect.SizeMode = PictureBoxSizeMode.StretchImage;
            picCatch.SizeMode = PictureBoxSizeMode.StretchImage;

            //chkMakePng.Checked = true;
            cmbOcrType.Items.Add("Digit");
            cmbOcrType.Items.Add("Float");
            cmbOcrType.Items.Add("Time");
            cmbOcrType.Items.Add("Math.");
            cmbOcrType.Items.Add("Text");
            cmbOcrType.SelectedIndex = 3;

            cmbSaveOcr.Items.Add("Verify-SET");
            cmbSaveOcr.Items.Add("Verify-CYCLE");
            cmbSaveOcr.Items.Add("auto-idle");
            cmbSaveOcr.Items.Add("PPID");
            cmbSaveOcr.Items.Add("PRESS-SET");
            cmbSaveOcr.Items.Add("PRESS-MON");
            cmbSaveOcr.Items.Add("STEP");
            cmbSaveOcr.Items.Add("VALVE-SET");
            cmbSaveOcr.Items.Add("VALVE-MON");
            cmbSaveOcr.Items.Add("RF-SET");
            cmbSaveOcr.Items.Add("RF-MON");
            cmbSaveOcr.Items.Add("RFr-SET");
            cmbSaveOcr.Items.Add("RFr-MON");
            cmbSaveOcr.Items.Add("GAS1-SET");
            cmbSaveOcr.Items.Add("GAS1-MON");
            cmbSaveOcr.Items.Add("GAS2-SET");
            cmbSaveOcr.Items.Add("GAS2-MON");
            cmbSaveOcr.Items.Add("TEMP1-SET");
            cmbSaveOcr.Items.Add("TEMP1-MON");
            cmbSaveOcr.Items.Add("TEMP2-SET");
            cmbSaveOcr.Items.Add("TEMP2-MON");
            cmbSaveOcr.Items.Add("TEMP3-SET");
            cmbSaveOcr.Items.Add("TEMP3-MON");
            cmbSaveOcr.Items.Add("EPD-SET");
            cmbSaveOcr.Items.Add("EPD-MON");
            cmbSaveOcr.Items.Add("TIME-SET");
            cmbSaveOcr.Items.Add("TIME-MON");
            cmbSaveOcr.Items.Add("CYCLE-SET");
            cmbSaveOcr.Items.Add("CYCLE-MON");
            cmbSaveOcr.Items.Add("auto-end");
            cmbSaveOcr.Items.Add("last");
            cmbSaveOcr.SelectedIndex = 0;

            clsJason jasonRead = new clsJason();
            jasonRead.readJason(m_StringLocalJasonFile, "OCR-NORMAL");
            m_ListJason = jasonRead.m_pOcrItems;
            Debug.WriteLine("################ MAIN OCR ITEMS]" + m_ListJason.Count);
        }

        
        private void PictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (bLeftButtonDown)
            {
                //X좌표 계산
                if (e.X < ClickPoint.X)
                {
                    CurrentTopLeft.X = e.X;
                    CurrentBottomRight.X = ClickPoint.X;
                }
                else
                {
                    CurrentTopLeft.X = ClickPoint.X;
                    CurrentBottomRight.X = e.X;
                }
                //Y좌표계산
                if (e.Y < ClickPoint.Y)
                {
                    CurrentTopLeft.Y = e.Y;
                    CurrentBottomRight.Y = ClickPoint.Y;
                }
                else
                {
                    CurrentTopLeft.Y = ClickPoint.Y;
                    CurrentBottomRight.Y = e.Y;
                }

                //화면초기화
                pictureBox1.Refresh();
                //사각형 그리기
                g.DrawRectangle(MyPen, CurrentTopLeft.X, CurrentTopLeft.Y, CurrentBottomRight.X - CurrentTopLeft.X,
               CurrentBottomRight.Y - CurrentTopLeft.Y);
            }
        }

        private void PictureBox1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if ((m_pMainContours.Length < 10) || (cmbSELECT.SelectedIndex != 2))
                return;
            String strRect = "";
            int nContourIdx = findSelectedCountours(e.Location, picSelect, pictureBox1, ref strRect);
            if (nContourIdx >= 0)
            {
                lblContID.Text = nContourIdx.ToString();
                lblRECT.Text = strRect;
                txtTEXT.Text = "";
                foreach (rawPicData rawInfo in m_ListPicSave)
                {
                    if (nContourIdx == rawInfo.index)
                    {
                        cmbTextType.SelectedIndex = rawInfo.type;
                        txtTEXT.Text = rawInfo.text;
                        break;
                    }
                }
            }
        }

        private void PictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (bLeftButtonDown == true)
            {
                if (cmbSELECT.SelectedIndex == 0)
                {
                    double x_ratio = 1, y_ratio = 1;
                    x_ratio = (double)matGRAY.Width / (double)pictureBox1.Width;
                    y_ratio = (double)matGRAY.Height / (double)pictureBox1.Height;
                    txtRectX.Text = ((int)(CurrentTopLeft.X * x_ratio)).ToString();
                    txtRectY.Text = ((int)(CurrentTopLeft.Y * y_ratio)).ToString();
                    txtRectWidth.Text = ((int)((CurrentBottomRight.X - CurrentTopLeft.X) * x_ratio)).ToString();
                    txtRectHeight.Text = ((int)((CurrentBottomRight.Y - CurrentTopLeft.Y) * y_ratio)).ToString();
                }
                else
                {
                    lblPOINT.Text = String.Format("{0}x{1} ==> {2}.{3}.{4}.{5}", picSize.Width, picSize.Height,
                        CurrentTopLeft.X, CurrentTopLeft.Y,
                        CurrentBottomRight.X - CurrentTopLeft.X,
                        CurrentBottomRight.Y - CurrentTopLeft.Y);
                    btnSelect.Enabled = true;
                }
            }
            bLeftButtonDown = false;
            this.Cursor = Cursors.Default;
            g.Dispose();
        }

        private void PictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if ((e.Button == MouseButtons) && (pictureBox1.Image != null))
            {
                btnSelect.Enabled = false;
                bLeftButtonDown = true;
                this.Cursor = Cursors.Cross;
                ClickPoint = new System.Drawing.Point(e.X, e.Y);
                lblPOINT.Text = String.Format("{0}.{1}", e.X, e.Y);
                //화면초기화
                pictureBox1.Refresh();
                g = this.pictureBox1.CreateGraphics();
            }
        }

        private void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            
        }

        ////////////////////////////////////////////////////////////////////////////////////////
        /// BUTTON HANDLER
        ////////////////////////////////////////////////////////////////////////////////////////

        private void BtnFileOCR_Click(object sender, EventArgs e)
        {
            if (m_bOcrLearn == false)
                return;
            m_OcrRun.OcrDoWindow(m_pOrgFileName, (Object)m_ListJason, matRUN.Width, matRUN.Height);
        }


        private void BtnSaveJason_Click(object sender, EventArgs e)
        {
            //m_StringLocalJasonFile 
            String writeInfo = "";
            // "Rect":{"Width":1274,"Height":404},
            if (matRUN.Width > 1000)
                writeInfo = "{\"OCR-NORMAL\":{\n";
            else
                writeInfo = "{\"OCR-SMALL\":{\n";
            // Rect:{"Width":234,"Height":20}
            writeInfo += String.Format("\t\"Rect\":{{\"Width\":{0},\"Height\":{1}}},\n", matRUN.Width, matRUN.Height);
            writeInfo += "\t\"Error-Save\":10,\n";
            List<jasonOcrRect> pOrdered = new List<jasonOcrRect>();
            int n;
            foreach(var cmbItems in cmbSaveOcr.Items)
            {
                Debug.WriteLine(cmbItems.ToString());
                for(n=0; n<m_ListJason.Count; n++)
                {
                    if(m_ListJason[n].Name == cmbItems.ToString())
                    {
                        pOrdered.Add(m_ListJason[n]);
                        break;
                    }
                }
            }
            if(pOrdered.Count < 2)
            {
                Debug.WriteLine("!!!!! NO ITEMS--->");
                return;
            }

            foreach(var pInfo in pOrdered)
            {
                writeInfo += String.Format("\t\"{0}\":{{\"x\":{1},\"y\":{2},\"Width\":{3},\"Height\":{4},\"Type\":{5},\"Verify\":\"{6}\"}},\n",
                    pInfo.Name, pInfo.X, pInfo.Y, pInfo.Width, pInfo.Height,
                    pInfo.Type, pInfo.Verify);
            }
            writeInfo += "}\n}";
            System.IO.File.WriteAllText(m_StringLocalJasonFile, writeInfo);
        }

        private void BtnOcrKeep_Click(object sender, EventArgs e)
        {
            String verifyText = "";
            int n;
            if (txtOcrResult.Text.Length == 0)
            {
                Debug.WriteLine("---> NO RESULT]" + cmbSaveOcr.Text);
                if ((cmbSaveOcr.Text != "VALVE-SET") && (cmbSaveOcr.Text != "RFr-SET") && (cmbSaveOcr.Text != "EPD-MON"))
                    return;
            }
            else
            {
                Debug.WriteLine("---> RESULT]" + cmbOcrType.SelectedIndex);
                if (cmbSaveOcr.Text.IndexOf("Verify-") >= 0)
                    verifyText = txtOcrResult.Text;
                else if (cmbOcrType.SelectedIndex == OcrUltima3.OCR_TYPE_DIGIT)
                {
                    if (int.TryParse(txtOcrResult.Text, out n) == false)
                        return;
                }
                else if (cmbOcrType.SelectedIndex == OcrUltima3.OCR_TYPE_FLOAT)
                {
                    double dVal;
                    if (double.TryParse(txtOcrResult.Text, out dVal) == false)
                        return;
                }
            }
            int nCurIdx = cmbSaveOcr.SelectedIndex;
            jasonOcrRect pCurJson = new jasonOcrRect();
            pCurJson.Name = cmbSaveOcr.Text;
            pCurJson.X = Convert.ToInt32(txtRectX.Text);
            pCurJson.Y = Convert.ToInt32(txtRectY.Text);
            pCurJson.Width = Convert.ToInt32(txtRectWidth.Text);
            pCurJson.Height = Convert.ToInt32(txtRectHeight.Text);
            pCurJson.Type = cmbOcrType.SelectedIndex;
            pCurJson.Verify = verifyText;
            var pFind = m_ListJason.Find(s => s.Name.Equals(cmbSaveOcr));
            if (pFind != null)
            {
                Debug.WriteLine(String.Format("----> KEEP FOUND] ORG={0},{1} With {2},{3}", pFind.X, pFind.Width, pCurJson.X, pCurJson.Width));
                pFind = pCurJson;
                //pFind.X = pCurJson.X;
            }
            else
                m_ListJason.Add(pCurJson);

            nCurIdx++;
            if(nCurIdx < cmbSaveOcr.Items.Count)
                cmbSaveOcr.SelectedIndex = nCurIdx;
            //cmbSaveOcr.Items.RemoveAt(nCurIdx);
            //cmbSaveOcr.SelectedIndex = 0;
            Debug.WriteLine(String.Format("COMBO]{0} <-- {1}", m_ListJason.Count, cmbSaveOcr.Items.Count));

            //if (m_ListJason.Count >= (cmbSaveOcr.Items.Count - 2))
                btnSaveJason.Enabled = true;
        }


        private void BtnDoOCR_Click(object sender, EventArgs e)
        {
            if (m_bOcrLearn == false)
                return;
            String ocrMessaege = m_OcrRun.DoOCR(matOCR, cmbOcrType.SelectedIndex);
            txtOcrResult.Text = ocrMessaege;
            btnOcrKeep.Enabled = true;
           
        }

        private void BtnViewRect_Click(object sender, EventArgs e)
        {
            int x, y, width, height;
            if (int.TryParse(txtRectX.Text, out x) == false)
                return;
            if (int.TryParse(txtRectY.Text, out y) == false)
                return;
            if (int.TryParse(txtRectWidth.Text, out width) == false)
                return;
            if (int.TryParse(txtRectHeight.Text, out height) == false)
                return;

            txtOcrResult.Text = "";

            matOCR = new Mat();
            matOCR = matORG.SubMat(new OpenCvSharp.Rect(x, y, width, height));
            picCatch.Image = BitmapConverter.ToBitmap(matOCR);
            String ocrNameString = cmbSaveOcr.Text;
            cmbOcrType.SelectedIndex = OcrUltima3.OCR_TYPE_DIGIT;
            if( (ocrNameString.IndexOf("auto") >= 0) || (ocrNameString.IndexOf("Verify") >= 0) || (ocrNameString.IndexOf("PPID") >= 0))
                cmbOcrType.SelectedIndex = OcrUltima3.OCR_TYPE_TEXT;
            else if (ocrNameString.IndexOf("STEP") >= 0)
                cmbOcrType.SelectedIndex = OcrUltima3.OCR_TYPE_MATH;
            else if (ocrNameString.IndexOf("VALVE") >= 0)
                cmbOcrType.SelectedIndex = OcrUltima3.OCR_TYPE_FLOAT;
            else if (ocrNameString.IndexOf("TIME") >= 0)
                cmbOcrType.SelectedIndex = OcrUltima3.OCR_TYPE_TIME;

            btnDoOCR.Enabled = true;
        }

        private void BtnLearnOCR_Click(object sender, EventArgs e)
        {
            var traingImages = m_pKnOcr.ReadTrainingImages(baseOcrFolder, "*.png");
            lblOCR.Text = String.Format("IMAGE]{0}", traingImages.Count);
            Debug.WriteLine("IMAGES]" + traingImages.Count);
            m_pKnOcr.TrainData2(traingImages);

            //m_OcrRun.setTextInfo(traingImages);
            m_OcrRun.initKnNearest(traingImages);

            m_bOcrLearn = true;
        }

        private void BtnPicSave_Click(object sender, EventArgs e)
        {
            foreach (rawPicData rawInfo in m_ListPicSave)
            {
                String localName = String.Format("{0}{1:000}.png", baseSaveFolder, rawInfo.index);
                if (System.IO.File.Exists(localName) == true)
                {
                    String destFolder = baseOcrFolder;
                    String baseDestName = rawInfo.text;
                    switch(rawInfo.type)
                    {
                        case OcrUltima3.TEXT_TYPE_DIGIT: destFolder += ocrFolderDigit; break;
                        case OcrUltima3.TEXT_TYPE_TEXT:
                            destFolder += ocrFolderText;
                            if(rawInfo.text.Length == 1)
                            {
                                if (baseDestName.Any(char.IsUpper) == true)
                                    baseDestName = "#" + rawInfo.text;
                            }
                            break;
                        case OcrUltima3.TEXT_TYPE_SYMBOL:
                            destFolder += ocrFolderSymbol;
                            baseDestName = "###" + rawInfo.text;
                            break;
                    }
                    baseDestName += "-";
                    String remoteName = destFolder + baseDestName + "0.png";
                    int n = 0;
                    do
                    {
                        remoteName = destFolder + baseDestName + String.Format("{0}.png", n);
                        if (System.IO.File.Exists(remoteName) == false)
                            break;
                        n++;
                    } while (n < 100);
                    System.IO.File.Copy(localName, remoteName);
                    System.IO.File.Delete(localName);
                    Debug.WriteLine(String.Format("LOCAL={0} REMOTE={1}", localName, remoteName));
                }
            }
        }

        private void BtnKeep_Click(object sender, EventArgs e)
        {
            int contId = 0;
            if (int.TryParse(lblContID.Text, out contId) == false)
                return;
            if (txtTEXT.Text.Length == 0)
            {
                txtTEXT.Focus();
                MessageBox.Show("ENTER TEXT", "WARING");
                return;
            }
            String baseFileName = String.Format("{0}{1:000}.png", baseSaveFolder, contId);
            if (System.IO.File.Exists(baseFileName) == false)
                saveContourPicture(contId);
            int n;
            for(n=0; n<m_ListPicSave.Count; n++)
            {
                if(m_ListPicSave[n].index == contId)
                {
                    m_ListPicSave[n].type = cmbTextType.SelectedIndex;
                    m_ListPicSave[n].text = txtTEXT.Text;
                }
            }
            if (n >= m_ListPicSave.Count)
            {
                m_ListPicSave.Add(new rawPicData(contId, cmbTextType.SelectedIndex, txtTEXT.Text));
            }
            txtTEXT.Text = "";
        }

        private void BtnRUN_Click(object sender, EventArgs e)
        {
            String strMsg = makeContours(chkMakePng.Checked);
            btnFileOCR.Enabled = true;
        }

        private void BtnSelect_Click(object sender, EventArgs e)
        {
            Rect pRect = new Rect(CurrentTopLeft.X, CurrentTopLeft.Y, CurrentBottomRight.X - CurrentTopLeft.X,
               CurrentBottomRight.Y - CurrentTopLeft.Y);
            Rect picRect = new Rect(0, 0, pictureBox1.Width, pictureBox1.Height);

            pictureBox1.Image = cropImage(m_pOrgFileName, pRect, picRect);
            btnRUN.Enabled = true;
        }

        private void BtnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDlg = new OpenFileDialog();
            openDlg.Filter = "BMP|*.bmp|GIF|*.gif|JPG|*.jpg;*.jpeg|PNG|*.png|TIFF|*.tif;*.tiff|"
       + "All Graphics Types|*.bmp;*.jpg;*.jpeg;*.png;*.tif;*.tiff";
            if (openDlg.ShowDialog() == DialogResult.OK)
            {
                txtFILE.Text = System.IO.Path.GetFileName(openDlg.FileName);
                pictureBox1.Image = Image.FromFile(openDlg.FileName);
                picSize.Width = pictureBox1.Image.Width;
                picSize.Height = pictureBox1.Image.Height;
                m_pOrgFileName = openDlg.FileName;
                //btnSelect.Enabled = true;
            }
        }

        private void CmbSELECT_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbSELECT.SelectedIndex < 0)
                return;
            btnViewRect.Enabled = false;
            btnDoOCR.Enabled = false;
            showSelected((Object)pictureBox1, cmbSELECT.SelectedIndex);
            if(cmbSELECT.SelectedIndex == 0)
                btnViewRect.Enabled = true;
        }



        ////////////////////////////////////////////////////////////////////////////////////
        /// Get Image
        /// ////////////////////////////////////////////////////////////////////////////////////

        Mat matORG = new Mat();
        Mat matRUN = new Mat();
        Mat matGRAY = new Mat();
        Mat matTHRESHOLD = new Mat();
        Mat matCONTOUR = new Mat();
        Mat matDIST = new Mat();
        Mat matOCR = new Mat();

        private System.Drawing.Bitmap cropImage(String fileName, Rect pRect, Rect picRect)
        {
            //Image retImg = null;
            System.Drawing.Bitmap retImg;

            var imgOrg = Cv2.ImRead(fileName);
            retImg = BitmapConverter.ToBitmap(imgOrg);

            m_OcrRun.findEdge(imgOrg);

            Debug.WriteLine(imgOrg.Width + "," + imgOrg.Height + String.Format(" <== PIC]{0},{1}", picRect.Width, picRect.Height));
            double x_ratio = 1, y_ratio = 1;
            x_ratio = (double)imgOrg.Width / (double)picRect.Width;
            y_ratio = (double)imgOrg.Height / (double)picRect.Height;
            Debug.WriteLine(String.Format("\t-->Ration]{0}  {1}", x_ratio, y_ratio));

            OpenCvSharp.Rect rect = new OpenCvSharp.Rect((int)(pRect.X * x_ratio), (int)(pRect.Y * y_ratio),
                (int)(pRect.Width * x_ratio), (int)(pRect.Height * y_ratio));
            if (m_OcrRun.m_bBasePointFound == true)
            {
                Debug.WriteLine("========> EDGE FOUND");
                rect = new OpenCvSharp.Rect((int)(m_OcrRun.m_pBasePoint.X), (int)(m_OcrRun.m_pBasePoint.Y),
                    (int)(pRect.Width * x_ratio), (int)(pRect.Height * y_ratio));
            }
            matRUN = imgOrg.SubMat(rect);
            Cv2.Resize(matRUN, matCONTOUR, new OpenCvSharp.Size(2, 2));
            matCONTOUR = imgOrg.SubMat(rect);
            Debug.WriteLine("\t===>CROPED]" + rect.ToString());
            retImg = BitmapConverter.ToBitmap(matRUN);
            //curGraphics = System.Drawing.Graphics.FromImage(retImg);

            return (retImg);
        }

        private const double Thresh = 80;
        private const double ThresholdMaxVal = 255;

        private OpenCvSharp.Point[][] m_pMainContours;
        private HierarchyIndex[] m_pHierarchyIndexes;
        //System.Drawing.Graphics curGraphics;
        private String makeContours(bool bFileMake)
        {
            String strMsg = "";
            if (matRUN == null)
            {
                strMsg = "INVALID MAT:";
                return (strMsg);
            }

            String baseFolder = @".\picSave\";
            if (System.IO.Directory.Exists(baseFolder) == false)
                System.IO.Directory.CreateDirectory(baseFolder);
            if (bFileMake == true)
            {
                System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(baseFolder);

                foreach (System.IO.FileInfo file in di.GetFiles())
                {
                    if (System.IO.Path.GetExtension(file.FullName) == ".png")
                        file.Delete();
                }
            }
            //matORG = new Mat();
            matORG = matCONTOUR.Clone();

            Cv2.CvtColor(matCONTOUR, matGRAY, ColorConversionCodes.BGRA2GRAY);
            //matCONTOUR = matRUN;

            var threshImage = new Mat();
            Cv2.Threshold(matGRAY, threshImage, Thresh, ThresholdMaxVal,
                ThresholdTypes.Binary | ThresholdTypes.Otsu); //ThresholdTypes.BinaryInv // Threshold to find contour
            matTHRESHOLD = threshImage;

            Mat matBitWise = new Mat();
            Cv2.BitwiseAnd(threshImage, threshImage, matBitWise, threshImage);
            threshImage = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);
            matGRAY = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);

            
            Cv2.FindContours(
                threshImage,
                out m_pMainContours,
                out m_pHierarchyIndexes,
                mode: RetrievalModes.CComp, // mode: RetrievalModes.CComp,
                method: ContourApproximationModes.ApproxSimple);

            if (m_pMainContours.Length == 0)
            {
                strMsg = "Couldn't find any object in the image.";
                return (strMsg);
            }
            //Cv2.DrawContours()

            //Create input sample by contour finding and cropping
            matDIST = new Mat(matCONTOUR.Rows, matCONTOUR.Cols, MatType.CV_8UC3, Scalar.All(0));

            System.Drawing.Bitmap pRunBmp = BitmapConverter.ToBitmap(matCONTOUR);
            System.Drawing.Graphics curGraphics = System.Drawing.Graphics.FromImage(pRunBmp);
            System.Drawing.Brush txtBrush = new System.Drawing.SolidBrush(System.Drawing.Color.YellowGreen);
            System.Drawing.Font txtFont = new System.Drawing.Font(new System.Drawing.FontFamily("굴림"), 14, System.Drawing.FontStyle.Bold,
                System.Drawing.GraphicsUnit.Pixel);

            List<Mat> matContList = new List<Mat>();
            var contourIndex = 0;
            while ((contourIndex >= 0))
            {
                var contour = m_pMainContours[contourIndex];

                var boundingRect = Cv2.BoundingRect(contour); //Find bounding rect for each contour
                if ((boundingRect.Width < 100) && (boundingRect.Height < 40))
                {

                    Cv2.Rectangle(matCONTOUR,
                        new OpenCvSharp.Point(boundingRect.X, boundingRect.Y),
                        new OpenCvSharp.Point(boundingRect.X + boundingRect.Width, boundingRect.Y + boundingRect.Height),
                        new Scalar(0, 0, 255),
                        1);

                    var roi = new Mat(threshImage, boundingRect); //Crop the image
                    if (compareMat(roi, matContList) == false)
                    {
                        if (bFileMake == true)
                            Cv2.ImWrite(String.Format("{0}{1:000}.png", baseFolder, contourIndex), roi);
                        matContList.Add(roi);
                        Cv2.PutText(matCONTOUR, String.Format("{0:000}", contourIndex),
                            new OpenCvSharp.Point(boundingRect.X, boundingRect.Y + boundingRect.Height + 8),
                            HersheyFonts.HersheyPlain, 0.5, Scalar.Yellow);
                    }

                    var resizedImage = new Mat();
                    var resizedImageFloat = new Mat();
                    Cv2.Resize(roi, resizedImage, new OpenCvSharp.Size(10, 10)); //resize to 10X10
                    resizedImage.ConvertTo(resizedImageFloat, MatType.CV_32FC1); //convert to float
                    var result = resizedImageFloat.Reshape(1, 1);


                    var results = new Mat();
                    var neighborResponses = new Mat();
                    var dists = new Mat();
                    //var detectedClass = (int)kNearest.FindNearest(result, 1, results, neighborResponses, dists);

                    //Cv2.PutText(
                    //    dst,
                    //    detectedClass.ToString(CultureInfo.InvariantCulture),
                    //    new OpenCvSharp.Point(boundingRect.X, boundingRect.Y + boundingRect.Height),
                    //    0,
                    //    1,
                    //    new Scalar(0, 255, 0),
                    //    2);
                }
                contourIndex = m_pHierarchyIndexes[contourIndex].Next;
            }
            Debug.WriteLine("COUNTOURED]" + m_pMainContours.Length);
            return (strMsg);
        }

        private int findSelectedCountours(System.Drawing.Point pPoint, PictureBox picShow, PictureBox picMain, ref String showRect)
        {
            int nContourIndex = 0;

            double x_ratio = 1, y_ratio = 1;
            x_ratio = (double)matCONTOUR.Width / (double)picMain.Width;
            y_ratio = (double)matCONTOUR.Height / (double)picMain.Height;

            int picX = (int)(x_ratio * pPoint.X);
            int picY = (int)(y_ratio * pPoint.Y);

            while ((nContourIndex >= 0))
            {
                var contour = m_pMainContours[nContourIndex];

                var boundingRect = Cv2.BoundingRect(contour); //Find bounding rect for each contour
                if ((boundingRect.Width < 100) && (boundingRect.Height < 40))
                {
                    if ((picX >= boundingRect.X) && (picX <= (boundingRect.X + boundingRect.Width))
                        && (picY >= boundingRect.Y) && (picY <= (boundingRect.Y + boundingRect.Height)))
                    {
                        Mat subRect = matGRAY.SubMat(new OpenCvSharp.Rect(boundingRect.X - 1, boundingRect.Y - 1, boundingRect.Width + 1, boundingRect.Height + 1));
                        picShow.Image = BitmapConverter.ToBitmap(subRect);
                        showRect = String.Format("{0},{1}  {2},{3}",
                            boundingRect.X, boundingRect.Y, boundingRect.Width, boundingRect.Height);
                        break;
                    }
                }
                nContourIndex = m_pHierarchyIndexes[nContourIndex].Next;
            }

            return (nContourIndex);
        }

        private void saveContourPicture(int reqIndex)
        {
            var nContourIndex = 0;
            while ((nContourIndex >= 0))
            {
                var contour = m_pMainContours[nContourIndex];
                if (nContourIndex == reqIndex)
                {
                    var boundingRect = Cv2.BoundingRect(contour);
                    var roi = new Mat(matGRAY, boundingRect); //Crop the image
                    Cv2.ImWrite(String.Format("{0}{1:000}.png", baseSaveFolder, nContourIndex), roi);
                    break;
                }
                nContourIndex = m_pHierarchyIndexes[nContourIndex].Next;
            }
        }

        private bool compareMat(Mat org, List<Mat> pList)
        {
            bool bSame = false;
            foreach (Mat pRun in pList)
            {
                if ((org.Width != pRun.Width) || (org.Height != pRun.Height))
                    continue;
                using (var comparison = new Mat())
                {
                    Cv2.Compare(org, pRun, comparison, CmpTypes.NE);
                    //Debug.WriteLine(comparison.Channels());
                    if (org.Channels() == 1)
                    {
                        if (Cv2.CountNonZero(comparison) == 0)
                        {
                            bSame = true;
                            break;
                        }
                        //Assert.Equal(0, Cv2.CountNonZero(comparison));
                    }
                    else
                    {
                        var channels = Cv2.Split(comparison);
                        Debug.WriteLine("---->split]" + channels.Length);
                        try
                        {
                            foreach (var channel in channels)
                            {
                                //Assert.Equal(0, Cv2.CountNonZero(channel));
                            }
                        }
                        finally
                        {
                            foreach (var channel in channels)
                            {
                                channel.Dispose();
                            }
                        }
                    }
                }
            }
            return bSame;
        }

       

        private void showSelected(object obj, int nSelected)
        {
            PictureBox picShow = obj as PictureBox;
            Mat matShow = null;
            //btnViewRect.Enabled = false;
            //btnDoOCR.Enabled = false;
            switch (nSelected)
            {
                case 0:
                    matShow = matORG;
                    break;
                case 1:
                    matShow = matGRAY;
                    //btnViewRect.Enabled = true;
                    break;
                case 2:
                    matShow = matCONTOUR;
                    break;
                case 3:
                    matShow = matDIST;
                    break;
            }
            if (matShow != null)
                picShow.Image = BitmapConverter.ToBitmap(matShow);
        }
    }

    public class rawPicData
    {
        public int index { get; set; }
        public int type { get; set; }
        public String text { get; set; }

        public rawPicData(int reqIdx, int reqType, String reqText)
        {
            this.index = reqIdx;
            this.type = reqType;
            this.text = reqText;
        }
    }
}
