﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace enCaptureUltima3.deviceRUN
{
    class clsLOG
    {
        public const String BASE_FOLDER = @"\enUlitma3Cap\";
        public const String FAIL_FOLDER = @"Error\";

        public static void initLogName()
        {
            String fileName = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + BASE_FOLDER;
            if (System.IO.Directory.Exists(fileName) == false)
                System.IO.Directory.CreateDirectory(fileName);

            String runFolder = fileName + @"Capture\";
            if (System.IO.Directory.Exists(runFolder) == false)
                System.IO.Directory.CreateDirectory(runFolder);

            runFolder = fileName + FAIL_FOLDER;
            if (System.IO.Directory.Exists(runFolder) == false)
                System.IO.Directory.CreateDirectory(runFolder);
        }

        public static void writeLogDevice(String fileName, int devNo, String strContents)
        {
            String strWrite = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + String.Format("\t{0}\t{1}\n", devNo, strContents);
            System.IO.File.AppendAllText(fileName, strWrite);
        }

        public static void writeLogDevice(int devNo, String strContents)
        {
            String fileName = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + BASE_FOLDER;
            if (System.IO.Directory.Exists(fileName) == false)
                System.IO.Directory.CreateDirectory(fileName);

            fileName = fileName + String.Format("enUltima{0}-{1}.txt", devNo, DateTime.Now.ToString("yyyyMMdd"));
            String strWrite = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff") + String.Format("\t{0}\t{1}\n", devNo, strContents);
            System.IO.File.AppendAllText(fileName, strWrite);
        }

        public static String getErrorPath()
        {
            String fileName = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + BASE_FOLDER;
            String runFolder = fileName + FAIL_FOLDER;
            return (runFolder);
        }

        public static String getCapturePath()
        {
            String fileName = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + BASE_FOLDER;
            String runFolder = fileName + @"Capture\";
            return (runFolder);
        }
    }
}
