﻿namespace enCaptureAnal
{
    partial class frmANAL
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPicSave = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnKeep = new System.Windows.Forms.Button();
            this.cmbTextType = new System.Windows.Forms.ComboBox();
            this.txtTEXT = new System.Windows.Forms.TextBox();
            this.picSelect = new System.Windows.Forms.PictureBox();
            this.lblContID = new System.Windows.Forms.Label();
            this.lblRECT = new System.Windows.Forms.Label();
            this.cmbSELECT = new System.Windows.Forms.ComboBox();
            this.btnRUN = new System.Windows.Forms.Button();
            this.lblPOINT = new System.Windows.Forms.Label();
            this.btnSelect = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtFILE = new System.Windows.Forms.TextBox();
            this.btnOpen = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblOCR = new System.Windows.Forms.Label();
            this.btnLearnOCR = new System.Windows.Forms.Button();
            this.chkMakePng = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtRectX = new System.Windows.Forms.TextBox();
            this.txtRectY = new System.Windows.Forms.TextBox();
            this.txtRectWidth = new System.Windows.Forms.TextBox();
            this.txtRectHeight = new System.Windows.Forms.TextBox();
            this.btnViewRect = new System.Windows.Forms.Button();
            this.picCatch = new System.Windows.Forms.PictureBox();
            this.btnDoOCR = new System.Windows.Forms.Button();
            this.txtOcrResult = new System.Windows.Forms.TextBox();
            this.cmbOcrType = new System.Windows.Forms.ComboBox();
            this.cmbSaveOcr = new System.Windows.Forms.ComboBox();
            this.btnOcrKeep = new System.Windows.Forms.Button();
            this.btnSaveJason = new System.Windows.Forms.Button();
            this.btnFileOCR = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSelect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCatch)).BeginInit();
            this.SuspendLayout();
            // 
            // btnPicSave
            // 
            this.btnPicSave.Location = new System.Drawing.Point(27, 207);
            this.btnPicSave.Name = "btnPicSave";
            this.btnPicSave.Size = new System.Drawing.Size(120, 27);
            this.btnPicSave.TabIndex = 23;
            this.btnPicSave.Text = "WriteAll";
            this.btnPicSave.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnKeep);
            this.groupBox1.Controls.Add(this.cmbTextType);
            this.groupBox1.Controls.Add(this.txtTEXT);
            this.groupBox1.Controls.Add(this.picSelect);
            this.groupBox1.Controls.Add(this.lblContID);
            this.groupBox1.Controls.Add(this.lblRECT);
            this.groupBox1.Location = new System.Drawing.Point(12, 43);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(316, 158);
            this.groupBox1.TabIndex = 22;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Text Type";
            // 
            // btnKeep
            // 
            this.btnKeep.Location = new System.Drawing.Point(176, 113);
            this.btnKeep.Name = "btnKeep";
            this.btnKeep.Size = new System.Drawing.Size(120, 27);
            this.btnKeep.TabIndex = 13;
            this.btnKeep.Text = "Keep";
            this.btnKeep.UseVisualStyleBackColor = true;
            // 
            // cmbTextType
            // 
            this.cmbTextType.FormattingEnabled = true;
            this.cmbTextType.Location = new System.Drawing.Point(176, 79);
            this.cmbTextType.Name = "cmbTextType";
            this.cmbTextType.Size = new System.Drawing.Size(120, 20);
            this.cmbTextType.TabIndex = 12;
            // 
            // txtTEXT
            // 
            this.txtTEXT.Location = new System.Drawing.Point(176, 52);
            this.txtTEXT.Name = "txtTEXT";
            this.txtTEXT.Size = new System.Drawing.Size(120, 21);
            this.txtTEXT.TabIndex = 11;
            // 
            // picSelect
            // 
            this.picSelect.Location = new System.Drawing.Point(15, 52);
            this.picSelect.Name = "picSelect";
            this.picSelect.Size = new System.Drawing.Size(129, 88);
            this.picSelect.TabIndex = 10;
            this.picSelect.TabStop = false;
            // 
            // lblContID
            // 
            this.lblContID.Location = new System.Drawing.Point(13, 17);
            this.lblContID.Name = "lblContID";
            this.lblContID.Size = new System.Drawing.Size(105, 23);
            this.lblContID.TabIndex = 9;
            this.lblContID.Text = "label1";
            this.lblContID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblRECT
            // 
            this.lblRECT.Location = new System.Drawing.Point(124, 17);
            this.lblRECT.Name = "lblRECT";
            this.lblRECT.Size = new System.Drawing.Size(174, 23);
            this.lblRECT.TabIndex = 8;
            this.lblRECT.Text = "label1";
            this.lblRECT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbSELECT
            // 
            this.cmbSELECT.FormattingEnabled = true;
            this.cmbSELECT.Location = new System.Drawing.Point(763, 11);
            this.cmbSELECT.Name = "cmbSELECT";
            this.cmbSELECT.Size = new System.Drawing.Size(139, 20);
            this.cmbSELECT.TabIndex = 21;
            // 
            // btnRUN
            // 
            this.btnRUN.Location = new System.Drawing.Point(548, 10);
            this.btnRUN.Name = "btnRUN";
            this.btnRUN.Size = new System.Drawing.Size(90, 27);
            this.btnRUN.TabIndex = 20;
            this.btnRUN.Text = "Run";
            this.btnRUN.UseVisualStyleBackColor = true;
            // 
            // lblPOINT
            // 
            this.lblPOINT.Location = new System.Drawing.Point(918, 10);
            this.lblPOINT.Name = "lblPOINT";
            this.lblPOINT.Size = new System.Drawing.Size(244, 23);
            this.lblPOINT.TabIndex = 19;
            this.lblPOINT.Text = "label1";
            this.lblPOINT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(441, 10);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(90, 27);
            this.btnSelect.TabIndex = 18;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.Location = new System.Drawing.Point(345, 43);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(979, 537);
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // txtFILE
            // 
            this.txtFILE.Location = new System.Drawing.Point(123, 14);
            this.txtFILE.Name = "txtFILE";
            this.txtFILE.Size = new System.Drawing.Size(302, 21);
            this.txtFILE.TabIndex = 16;
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(27, 10);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(90, 27);
            this.btnOpen.TabIndex = 15;
            this.btnOpen.Text = "Open";
            this.btnOpen.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnOcrKeep);
            this.groupBox2.Controls.Add(this.cmbSaveOcr);
            this.groupBox2.Controls.Add(this.cmbOcrType);
            this.groupBox2.Controls.Add(this.txtOcrResult);
            this.groupBox2.Controls.Add(this.btnDoOCR);
            this.groupBox2.Controls.Add(this.picCatch);
            this.groupBox2.Controls.Add(this.btnViewRect);
            this.groupBox2.Controls.Add(this.txtRectHeight);
            this.groupBox2.Controls.Add(this.txtRectWidth);
            this.groupBox2.Controls.Add(this.txtRectY);
            this.groupBox2.Controls.Add(this.txtRectX);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.lblOCR);
            this.groupBox2.Controls.Add(this.btnLearnOCR);
            this.groupBox2.Location = new System.Drawing.Point(13, 241);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(315, 294);
            this.groupBox2.TabIndex = 24;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "OCR Group";
            // 
            // lblOCR
            // 
            this.lblOCR.Location = new System.Drawing.Point(151, 29);
            this.lblOCR.Name = "lblOCR";
            this.lblOCR.Size = new System.Drawing.Size(105, 23);
            this.lblOCR.TabIndex = 25;
            this.lblOCR.Text = "label1";
            this.lblOCR.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnLearnOCR
            // 
            this.btnLearnOCR.Location = new System.Drawing.Point(14, 29);
            this.btnLearnOCR.Name = "btnLearnOCR";
            this.btnLearnOCR.Size = new System.Drawing.Size(120, 27);
            this.btnLearnOCR.TabIndex = 24;
            this.btnLearnOCR.Text = "Learn OCR";
            this.btnLearnOCR.UseVisualStyleBackColor = true;
            // 
            // chkMakePng
            // 
            this.chkMakePng.AutoSize = true;
            this.chkMakePng.Location = new System.Drawing.Point(655, 16);
            this.chkMakePng.Name = "chkMakePng";
            this.chkMakePng.Size = new System.Drawing.Size(85, 16);
            this.chkMakePng.TabIndex = 25;
            this.chkMakePng.Text = "Make PNG";
            this.chkMakePng.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 12);
            this.label1.TabIndex = 26;
            this.label1.Text = "Rect";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtRectX
            // 
            this.txtRectX.Location = new System.Drawing.Point(50, 72);
            this.txtRectX.Name = "txtRectX";
            this.txtRectX.Size = new System.Drawing.Size(54, 21);
            this.txtRectX.TabIndex = 27;
            // 
            // txtRectY
            // 
            this.txtRectY.Location = new System.Drawing.Point(110, 72);
            this.txtRectY.Name = "txtRectY";
            this.txtRectY.Size = new System.Drawing.Size(54, 21);
            this.txtRectY.TabIndex = 28;
            // 
            // txtRectWidth
            // 
            this.txtRectWidth.Location = new System.Drawing.Point(171, 72);
            this.txtRectWidth.Name = "txtRectWidth";
            this.txtRectWidth.Size = new System.Drawing.Size(60, 21);
            this.txtRectWidth.TabIndex = 29;
            // 
            // txtRectHeight
            // 
            this.txtRectHeight.Location = new System.Drawing.Point(237, 72);
            this.txtRectHeight.Name = "txtRectHeight";
            this.txtRectHeight.Size = new System.Drawing.Size(60, 21);
            this.txtRectHeight.TabIndex = 30;
            // 
            // btnViewRect
            // 
            this.btnViewRect.Location = new System.Drawing.Point(14, 99);
            this.btnViewRect.Name = "btnViewRect";
            this.btnViewRect.Size = new System.Drawing.Size(82, 27);
            this.btnViewRect.TabIndex = 31;
            this.btnViewRect.Text = "View";
            this.btnViewRect.UseVisualStyleBackColor = true;
            // 
            // picCatch
            // 
            this.picCatch.Location = new System.Drawing.Point(110, 99);
            this.picCatch.Name = "picCatch";
            this.picCatch.Size = new System.Drawing.Size(185, 88);
            this.picCatch.TabIndex = 32;
            this.picCatch.TabStop = false;
            // 
            // btnDoOCR
            // 
            this.btnDoOCR.Location = new System.Drawing.Point(12, 215);
            this.btnDoOCR.Name = "btnDoOCR";
            this.btnDoOCR.Size = new System.Drawing.Size(82, 27);
            this.btnDoOCR.TabIndex = 33;
            this.btnDoOCR.Text = "OCR";
            this.btnDoOCR.UseVisualStyleBackColor = true;
            // 
            // txtOcrResult
            // 
            this.txtOcrResult.Location = new System.Drawing.Point(108, 219);
            this.txtOcrResult.Name = "txtOcrResult";
            this.txtOcrResult.Size = new System.Drawing.Size(187, 21);
            this.txtOcrResult.TabIndex = 34;
            // 
            // cmbOcrType
            // 
            this.cmbOcrType.FormattingEnabled = true;
            this.cmbOcrType.Location = new System.Drawing.Point(110, 193);
            this.cmbOcrType.Name = "cmbOcrType";
            this.cmbOcrType.Size = new System.Drawing.Size(139, 20);
            this.cmbOcrType.TabIndex = 35;
            // 
            // cmbSaveOcr
            // 
            this.cmbSaveOcr.FormattingEnabled = true;
            this.cmbSaveOcr.Location = new System.Drawing.Point(14, 257);
            this.cmbSaveOcr.Name = "cmbSaveOcr";
            this.cmbSaveOcr.Size = new System.Drawing.Size(169, 20);
            this.cmbSaveOcr.TabIndex = 36;
            // 
            // btnOcrKeep
            // 
            this.btnOcrKeep.Location = new System.Drawing.Point(189, 253);
            this.btnOcrKeep.Name = "btnOcrKeep";
            this.btnOcrKeep.Size = new System.Drawing.Size(108, 27);
            this.btnOcrKeep.TabIndex = 37;
            this.btnOcrKeep.Text = "Keep";
            this.btnOcrKeep.UseVisualStyleBackColor = true;
            // 
            // btnSaveJason
            // 
            this.btnSaveJason.Location = new System.Drawing.Point(13, 551);
            this.btnSaveJason.Name = "btnSaveJason";
            this.btnSaveJason.Size = new System.Drawing.Size(84, 27);
            this.btnSaveJason.TabIndex = 26;
            this.btnSaveJason.Text = "To Jason";
            this.btnSaveJason.UseVisualStyleBackColor = true;
            // 
            // btnFileOCR
            // 
            this.btnFileOCR.Location = new System.Drawing.Point(221, 551);
            this.btnFileOCR.Name = "btnFileOCR";
            this.btnFileOCR.Size = new System.Drawing.Size(107, 27);
            this.btnFileOCR.TabIndex = 28;
            this.btnFileOCR.Text = "File OCR";
            this.btnFileOCR.UseVisualStyleBackColor = true;
            // 
            // frmANAL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1337, 590);
            this.Controls.Add(this.btnFileOCR);
            this.Controls.Add(this.btnSaveJason);
            this.Controls.Add(this.chkMakePng);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnPicSave);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmbSELECT);
            this.Controls.Add(this.btnRUN);
            this.Controls.Add(this.lblPOINT);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.txtFILE);
            this.Controls.Add(this.btnOpen);
            this.Name = "frmANAL";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmANAL_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSelect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picCatch)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPicSave;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnKeep;
        private System.Windows.Forms.ComboBox cmbTextType;
        private System.Windows.Forms.TextBox txtTEXT;
        private System.Windows.Forms.PictureBox picSelect;
        private System.Windows.Forms.Label lblContID;
        private System.Windows.Forms.Label lblRECT;
        private System.Windows.Forms.ComboBox cmbSELECT;
        private System.Windows.Forms.Button btnRUN;
        private System.Windows.Forms.Label lblPOINT;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtFILE;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblOCR;
        private System.Windows.Forms.Button btnLearnOCR;
        private System.Windows.Forms.CheckBox chkMakePng;
        private System.Windows.Forms.TextBox txtRectX;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtRectY;
        private System.Windows.Forms.TextBox txtRectHeight;
        private System.Windows.Forms.TextBox txtRectWidth;
        private System.Windows.Forms.TextBox txtOcrResult;
        private System.Windows.Forms.Button btnDoOCR;
        private System.Windows.Forms.PictureBox picCatch;
        private System.Windows.Forms.Button btnViewRect;
        private System.Windows.Forms.ComboBox cmbOcrType;
        private System.Windows.Forms.Button btnOcrKeep;
        private System.Windows.Forms.ComboBox cmbSaveOcr;
        private System.Windows.Forms.Button btnSaveJason;
        private System.Windows.Forms.Button btnFileOCR;
    }
}

