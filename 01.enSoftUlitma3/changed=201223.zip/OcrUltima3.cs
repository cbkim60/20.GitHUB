﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using OpenCvSharp;
using OpenCvSharp.Extensions;
using OpenCvSharp.ML;
using System.Diagnostics;

namespace enUltima3Capture
{
    public class contourInfo
    {
        public int x { get; set; }
        public int y { get; set; }
        public int width { get; set; }
        public int height { get; set; }
        public String Text { get; set; }
    }

    class OcrUltima3
    {
        public const int TEXT_TYPE_DIGIT = 0;
        public const int TEXT_TYPE_SYMBOL = 1;
        public const int TEXT_TYPE_FLOAT = 2;
        public const int TEXT_TYPE_MATH = 3;
        public const int TEXT_TYPE_TIME = 4;
        public const int TEXT_TYPE_TEXT = 5;

        public const int OCR_TYPE_DIGIT = 0;
        public const int OCR_TYPE_FLOAT = 1;
        public const int OCR_TYPE_TIME = 2;
        public const int OCR_TYPE_MATH = 3;
        public const int OCR_TYPE_TEXT = 4;

        private const int knnNearestK = 1;

        public OpenCvSharp.Point m_pBasePoint = new Point(0, 0);
        public bool m_bBasePointFound = false;

        public KNearest m_pKnN = null;
        public KNearest m_pKnDigit = null;
        public KNearest m_pKnFloat = null;
        public KNearest m_pKnMath = null;
        public KNearest m_pKnTime = null;

        public List<ImageTextInfo> m_pTextArray = new List<ImageTextInfo>();

        public bool m_bOcrResult = false;
        public System.Drawing.Bitmap m_ImgGray;
        public String m_OCR_ERROR = "";
        //public Mat m_ImgGRAY = new Mat();

        public void initKnNearest(IList<ImageInfo> pImages)
        {
            setTextInfo(pImages);
            //m_pKnN = knOCR.TrainData3(pImages);
            int n;
            for(n= TEXT_TYPE_DIGIT; n<= TEXT_TYPE_TEXT; n++)
            {
                var images = new List<ImageInfo>();
                foreach (ImageInfo pImg in pImages)
                {
                    bool bInsert = false;
                    switch (pImg.ImageType)
                    {
                        case TEXT_TYPE_DIGIT:
                            bInsert = true;
                            break;
                        case TEXT_TYPE_FLOAT:
                        case TEXT_TYPE_MATH:
                        case TEXT_TYPE_TIME:
                        case TEXT_TYPE_TEXT:
                            if (n == pImg.ImageType)
                                bInsert = true;
                            break;
                    }
                    if (bInsert == true)
                    {
                        images.Add(new ImageInfo
                        {
                            Image = pImg.Image,
                            ImageId = pImg.ImageId,
                            ImageGroupId = pImg.ImageGroupId,
                            ImageType = pImg.ImageType,
                            Text = pImg.Text
                        });
                    }
                }
                Debug.WriteLine(String.Format("initKnNearest]{0} --> {1}", n, images.Count));
                if (images.Count > 0)
                {
                    switch(n)
                    {
                        case TEXT_TYPE_DIGIT:
                            m_pKnDigit = knOCR.TrainData3(images);
                            break;
                        case TEXT_TYPE_FLOAT:
                            m_pKnFloat = knOCR.TrainData3(images);
                            break;
                        case TEXT_TYPE_MATH:
                            m_pKnMath = knOCR.TrainData3(images);
                            break;
                        case TEXT_TYPE_TIME:
                            m_pKnTime = knOCR.TrainData3(images);
                            break;
                        case TEXT_TYPE_TEXT:
                            m_pKnN = knOCR.TrainData3(images);
                            break;
                    }
                }
            }
        }

        public void setTextInfo(IList<ImageInfo> pImages)
        {
            m_pTextArray.Clear();

            foreach(var img in pImages)
            {
                ImageTextInfo pText = new ImageTextInfo();
                pText.ImageId = img.ImageId;
                pText.ImageType = img.ImageType;
                pText.Text = img.Text;
                m_pTextArray.Add(pText);
            }
            Debug.WriteLine("===========> ARRAY COUNT]" + m_pTextArray.Count);
        }

        public OpenCvSharp.Point findEdge(Mat orgMat)
        {
            OpenCvSharp.Point p = new OpenCvSharp.Point(0, 0);

            Mat src1 = orgMat.SubMat(new OpenCvSharp.Rect(0, 0, 500, 200));
            src1 = OcrUltima3.updateBrightnessContrast(src1, 100, 150);
            if (src1 == null)
                return (p);
            Cv2.Threshold(src1, src1, 150, 255, ThresholdTypes.Tozero);
            Cv2.Threshold(src1, src1, 150, 255, ThresholdTypes.Binary);

            for (int i = 0; i < src1.Rows; i++)
            {
                for (int j = 0; j < src1.Cols; j++)
                {
                    var data = src1.At<byte>(i, j);
                    if (data == 0xFF)
                    {
                        m_pBasePoint = new OpenCvSharp.Point(j, i);
                        m_bBasePointFound = true;
                        return (m_pBasePoint);
                        //return (new OpenCvSharp.Point(j, i)); // ????
                    }
                }
            }
            return (p);
        }

        public OpenCvSharp.Point findEdge(String fileName)
        {
            OpenCvSharp.Point p = new OpenCvSharp.Point(0, 0);

            m_bBasePointFound = false;
            Mat orgMat = Cv2.ImRead(fileName);
            Mat src1 = orgMat.SubMat(new OpenCvSharp.Rect(0, 0, 500, 200));
            src1 = OcrUltima3.updateBrightnessContrast(src1, 100, 150);
            if (src1 == null)
                return (p);
            Cv2.Threshold(src1, src1, 150, 255, ThresholdTypes.Tozero);
            Cv2.Threshold(src1, src1, 150, 255, ThresholdTypes.Binary);

            for (int i = 0; i < src1.Rows; i++)
            {
                for (int j = 0; j < src1.Cols; j++)
                {
                    var data = src1.At<byte>(i, j);
                    if (data == 0xFF)
                    {
                        m_pBasePoint = new OpenCvSharp.Point(j, i);
                        m_bBasePointFound = true;
                        Debug.WriteLine("POINT]" + m_pBasePoint.X);
                        return (m_pBasePoint);
                        //return (new OpenCvSharp.Point(j, i)); // ????
                    }
                }
            }
            return (p);
        }

        public static Mat updateBrightnessContrast(Mat src, int brightness, int contrast)
        {
            Mat modifiedSrc = src;

            if (src.Rows == 0)
                return null;

            int rBrightness = brightness - 100;
            int rContrast = contrast - 100;

            double alpha, beta;
            if (rContrast > 0)
            {
                double delta = 127f * rContrast / 100f;
                alpha = 255f / (255f - delta * 2);
                beta = alpha * (rBrightness - delta);
            }
            else
            {
                double delta = -128f * rContrast / 100;
                alpha = (256f - delta * 2) / 255f;
                beta = alpha * rBrightness + delta;
            }
            src.ConvertTo(modifiedSrc, MatType.CV_8U, alpha, beta); // jung code
            //src.ConvertTo(modifiedSrc, MatType.CV_8UC3, alpha, beta);

            return (modifiedSrc);
        }

        private const double Thresh = 80;
        private const double ThresholdMaxVal = 255;
        public String OCR_STRING = "";
        public int m_nOcrContourTotal = 0;
        public int m_nOcrContourRun = 0;

        private List<contourInfo> runContours(Mat baseMat, int ocrType, bool madeGray = true)
        {
            List<contourInfo> pListText = new List<contourInfo>();

            m_nOcrContourTotal = 0;
            m_nOcrContourRun = 0;
            KNearest kNearest = m_pKnN;
            switch (ocrType)
            {
                case OCR_TYPE_DIGIT:
                    kNearest = m_pKnDigit;
                    break;
                case OCR_TYPE_FLOAT:
                    kNearest = m_pKnFloat;
                    break;
                case OCR_TYPE_TIME:
                    kNearest = m_pKnTime;
                    break;
                case OCR_TYPE_MATH:
                    kNearest = m_pKnMath;
                    break;
            }
            var gray = new Mat();
            //Cv2.ImShow("OCR", baseMat);
            if (madeGray == true)
                Cv2.CvtColor(baseMat, gray, ColorConversionCodes.BGRA2GRAY);
            else
                gray = baseMat.Clone();

            var threshImage = new Mat();
            //Cv2.Threshold(gray, threshImage, Thresh, ThresholdMaxVal, ThresholdTypes.BinaryInv); // Threshold to find contour
            Cv2.Threshold(gray, threshImage, Thresh, ThresholdMaxVal,
               ThresholdTypes.Binary | ThresholdTypes.Otsu);

            Mat matBitWise = new Mat();
            Cv2.BitwiseAnd(threshImage, threshImage, matBitWise, threshImage);
            threshImage = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);
            gray = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);


            Point[][] contours;
            HierarchyIndex[] hierarchyIndexes;
            Cv2.FindContours(
                threshImage,
                out contours,
                out hierarchyIndexes,
                mode: RetrievalModes.CComp,
                method: ContourApproximationModes.ApproxSimple);

            m_nOcrContourTotal = contours.Length;
            if (contours.Length == 0)
            {
                Debug.WriteLine("!!!!!!DoOCR] No Contours");
                return (pListText);
            }

            //Create input sample by contour finding and cropping
            var dst = new Mat(baseMat.Rows, baseMat.Cols, MatType.CV_8UC3, Scalar.All(0));

            var contourIndex = 0;
            int nBottom = baseMat.Height + 2;

            int runY = 100, runHeight = 0;
            List<System.Drawing.Rectangle> pRectContuours = new List<System.Drawing.Rectangle>();
            while ((contourIndex >= 0))
            {
                var contour = contours[contourIndex];
                var boundingRect = Cv2.BoundingRect(contour);
                if ((boundingRect.Width < 60) && (boundingRect.Height < 22))
                {
                    // OCR#0=10 FROM=96,11 21,9
                    // OCR#1=5 FROM=96,6 19,8
                    // OCR#2=27 FROM=61,6 21,14 --> NORMAL
                    // OCR#3=21 FROM=30,6 12,14 --> NORMAL
                    Debug.WriteLine("RECT1]" + boundingRect.ToString());
                    if (nBottom > (boundingRect.Y + boundingRect.Height))
                        nBottom = boundingRect.Y + boundingRect.Height;
                    //if ((boundingRect.Height < 18) && (boundingRect.Height > 1))
                    {
                        if (boundingRect.Y < runY)
                            runY = boundingRect.Y;
                        if (boundingRect.Height > runHeight)
                            runHeight = boundingRect.Height;
                        System.Drawing.Rectangle pBoundRect = new System.Drawing.Rectangle();
                        pBoundRect.X = boundingRect.X;
                        pBoundRect.Y = boundingRect.Y;
                        pBoundRect.Width = boundingRect.Width;
                        pBoundRect.Height = boundingRect.Height;
                        pRectContuours.Add(pBoundRect);
                    }
                }
                contourIndex = hierarchyIndexes[contourIndex].Next;
            }
            if (pRectContuours.Count == 0)
                return (pListText);

            //var orderedRun = pRectContuours.OrderBy(s => s.X);
            //var orderedBound = orderedRun as List<System.Drawing.Rectangle>;
            //List<System.Drawing.Rectangle> orderedBound = (List < System.Drawing.Rectangle > )pRectContuours.OrderBy(s => s.X);
            var orderedBound = pRectContuours.OrderBy(s => s.X);
            int nCount = 0;
            foreach(var boundInfo in orderedBound)
            {
                if(nCount == 0)
                {
                    contourInfo pNew = new contourInfo();
                    pNew.x = boundInfo.X;
                    pNew.y = boundInfo.Y;
                    pNew.width = boundInfo.Width;
                    pNew.height = boundInfo.Height;
                    pNew.Text = "";
                    pListText.Add(pNew);
                }
                else
                {
                    int nCurBottom = boundInfo.Y + boundInfo.Height;
                    int nArea = boundInfo.Width + boundInfo.Height;
                    if (nCurBottom < (nBottom - 4))
                    {
                        if (nArea > 10)
                        {
                            int nLastIdx = pListText.Count - 1;
                            int nPrevRange = pListText[nLastIdx].x + pListText[nLastIdx].x;
                            if ((boundInfo.X >= (pListText[nLastIdx].x + pListText[nLastIdx].width) && (boundInfo.X <= nPrevRange)))
                            {
                                contourInfo pNew = new contourInfo();
                                pNew.x = pListText[nLastIdx].x;
                                pNew.y = boundInfo.Y;
                                pNew.width = pListText[nLastIdx].x - boundInfo.X + pListText[nLastIdx].width;
                                pNew.height += boundInfo.Height;
                                pListText[nLastIdx] = pNew;
                            }
                        }
                    }
                    else
                    {
                        contourInfo pNew = new contourInfo();
                        pNew.x = boundInfo.X;
                        pNew.y = boundInfo.Y;
                        pNew.width = boundInfo.Width;
                        pNew.height = boundInfo.Height;
                        pNew.Text = "";
                        pListText.Add(pNew);
                    }
                }
                nCount++;
            }

            foreach (var pRect in pListText)
            {
                //Debug.WriteLine("RECT2]" + pRect.ToString());
                var boundingRect = new Rect(pRect.x, pRect.y, pRect.width, pRect.height);
                var roi = new Mat(threshImage, boundingRect);

                var resizedImage = new Mat();
                var resizedImageFloat = new Mat();
                Cv2.Resize(roi, resizedImage, new Size(10, 10)); //resize to 10X10
                                                                 //Cv2.Resize(roi, resizedImage, new Size(1, 1));
                resizedImage.ConvertTo(resizedImageFloat, MatType.CV_32FC1); //convert to float
                var result = resizedImageFloat.Reshape(1, 1);

                var results = new Mat();
                var neighborResponses = new Mat();
                var dists = new Mat();
                var detectedClass = (int)kNearest.FindNearest(result, knnNearestK, results, neighborResponses, dists);
                Debug.WriteLine(String.Format("OCR#{0}={1} FROM={2},{3} {4},{5}",
                    contourIndex, detectedClass.ToString(), boundingRect.X, boundingRect.Y, boundingRect.Width, boundingRect.Height));
                String getOcrIndex = detectedClass.ToString();
                Debug.WriteLine("\t--->SCANNED]" + getOcrIndex + String.Format(" FROM {0} with {1}", pListText.Count, m_pTextArray.Count));
                pRect.Text = getOcrIndex;
                var pText = m_pTextArray.Find(x => (x.ImageId == detectedClass));
                if (pText != null)
                {
                    OCR_STRING += pText.Text;
                    pRect.Text = pText.Text;
                    Debug.WriteLine(String.Format("\t---->TEXT]{0} FROM {1}", pText.Text, getOcrIndex));
                }
                m_nOcrContourRun++;
            }

            //foreach (var pRect in pListText)
            //{
            //    int setY = runY, setHeight = runHeight;
            //    if ((pRect.height < 4) || (ocrType == OCR_TYPE_TEXT))
            //    {
            //        // RECT2]{x:105 y:20 width:5 height:2)
            //        setY = pRect.y;
            //        setHeight = pRect.height;
            //    }
            //    Debug.WriteLine("RECT2]" + pRect.ToString());
            //    var boundingRect = new Rect(pRect.x, setY, pRect.width, setHeight);
            //    Debug.WriteLine("BOUNDING]" + boundingRect.ToString());
            //    var roi = new Mat(threshImage, boundingRect); //Crop the image

            //    var resizedImage = new Mat();
            //    var resizedImageFloat = new Mat();
            //    Cv2.Resize(roi, resizedImage, new Size(10, 10)); //resize to 10X10
            //                                                     //Cv2.Resize(roi, resizedImage, new Size(1, 1));
            //    resizedImage.ConvertTo(resizedImageFloat, MatType.CV_32FC1); //convert to float
            //    var result = resizedImageFloat.Reshape(1, 1);


            //    var results = new Mat();
            //    var neighborResponses = new Mat();
            //    var dists = new Mat();
            //    var detectedClass = (int)kNearest.FindNearest(result, knnNearestK, results, neighborResponses, dists);
            //    Debug.WriteLine(String.Format("OCR#{0}={1} FROM={2},{3} {4},{5}",
            //        contourIndex, detectedClass.ToString(), boundingRect.X, boundingRect.Y, boundingRect.Width, boundingRect.Height));
            //    String getOcrIndex = detectedClass.ToString();
            //    Debug.WriteLine("\t--->SCANNED]" + getOcrIndex + String.Format(" FROM {0}", pListText.Count));
            //    var pText = m_pTextArray.Find(x => (x.ImageId == detectedClass));
            //    if (pText != null)
            //    {
            //        OCR_STRING += pText.Text;
            //        pRect.Text = pText.Text;
            //    }
            //    m_nOcrContourRun++;
            //}



            //if ((runY < 18) && (runHeight < 18))
            //{
            //    foreach (var pRect in orderedBound)
            //    {
            //        int setY = runY, setHeight = runHeight;
            //        if ((pRect.Height < 4) || (ocrType == OCR_TYPE_TEXT))
            //        {
            //            // RECT2]{x:105 y:20 width:5 height:2)
            //            setY = pRect.Y;
            //            setHeight = pRect.Height;
            //        }
            //        Debug.WriteLine("RECT2]" + pRect.ToString());
            //        var boundingRect = new Rect(pRect.X, setY, pRect.Width, setHeight);
            //        Debug.WriteLine("BOUNDING]" + boundingRect.ToString());
            //        var roi = new Mat(threshImage, boundingRect); //Crop the image

            //        var resizedImage = new Mat();
            //        var resizedImageFloat = new Mat();
            //        Cv2.Resize(roi, resizedImage, new Size(10, 10)); //resize to 10X10
            //        //Cv2.Resize(roi, resizedImage, new Size(1, 1));
            //        resizedImage.ConvertTo(resizedImageFloat, MatType.CV_32FC1); //convert to float
            //        var result = resizedImageFloat.Reshape(1, 1);


            //        var results = new Mat();
            //        var neighborResponses = new Mat();
            //        var dists = new Mat();
            //        var detectedClass = (int)kNearest.FindNearest(result, knnNearestK, results, neighborResponses, dists);
            //        Debug.WriteLine(String.Format("OCR#{0}={1} FROM={2},{3} {4},{5}",
            //            contourIndex, detectedClass.ToString(), boundingRect.X, boundingRect.Y, boundingRect.Width, boundingRect.Height));
            //        String getOcrIndex = detectedClass.ToString();
            //        Debug.WriteLine("\t--->SCANNED]" + getOcrIndex);
            //        var pText = m_pTextArray.Find(x => (x.ImageId == detectedClass));
            //        if (pText != null)
            //        {
            //            OCR_STRING += pText.Text;
            //            contourInfo pInfo = new contourInfo();
            //            pInfo.x = boundingRect.X;
            //            pInfo.width = boundingRect.Width;
            //            pInfo.Text = pText.Text;
            //            pListText.Add(pInfo);
            //        }
            //        m_nOcrContourRun++;
            //    }
            //}

            //contourIndex = 0;
            //while ((contourIndex >= 0))
            //{
            //    var contour = contours[contourIndex];

            //    var boundingRect = Cv2.BoundingRect(contour); //Find bounding rect for each contour
            //    if ((boundingRect.Width < 60) && (boundingRect.Height < 24))
            //    {
            //        var roi = new Mat(threshImage, boundingRect); //Crop the image

            //        var resizedImage = new Mat();
            //        var resizedImageFloat = new Mat();
            //        Cv2.Resize(roi, resizedImage, new Size(10, 10)); //resize to 10X10
            //        //Cv2.Resize(roi, resizedImage, new Size(1, 1));
            //        resizedImage.ConvertTo(resizedImageFloat, MatType.CV_32FC1); //convert to float
            //        var result = resizedImageFloat.Reshape(1, 1);


            //        var results = new Mat();
            //        var neighborResponses = new Mat();
            //        var dists = new Mat();
            //        var detectedClass = (int)kNearest.FindNearest(result, knnNearestK, results, neighborResponses, dists);
            //        Debug.WriteLine(String.Format("OCR#{0}={1} FROM={2},{3}", contourIndex, detectedClass.ToString(), boundingRect.Width, boundingRect.Height));
            //        String getOcrIndex = detectedClass.ToString();
            //        if (getOcrIndex != "0")
            //        {
            //            ocrString += (detectedClass.ToString() + "\t");
            //            var pText = m_pTextArray.Find(x => (x.ImageId == detectedClass));
            //            if (pText != null)
            //            {
            //                OCR_STRING += pText.Text;
            //                contourInfo pInfo = new contourInfo();
            //                pInfo.x = boundingRect.X;
            //                pInfo.width = boundingRect.Width;
            //                pInfo.Text = pText.Text;
            //                pListText.Add(pInfo);
            //            }
            //            m_nOcrContourRun++;
            //        }

            //        //Cv2.PutText(
            //        //    dst,
            //        //    detectedClass.ToString(CultureInfo.InvariantCulture),
            //        //    new Point(boundingRect.X, boundingRect.Y + boundingRect.Height),
            //        //    0,
            //        //    1,
            //        //    new Scalar(0, 255, 0),
            //        //    2);
            //    }
            //    contourIndex = hierarchyIndexes[contourIndex].Next;
            //}

            return (pListText);
        }

        public String DoOCR(Mat baseMat, int ocrType, bool bSmallSize = false)
        {
            String ocrString = "";
            OCR_STRING = "";

            var orderedList = runContours(baseMat, ocrType);

            //var orderedList = pListText.OrderBy(s => s.x);
            int prevX = -1000, prevWidth = 0;
            String viewText = "";
            int spaceLen = 22;
            if (ocrType == OCR_TYPE_TEXT)
                spaceLen = 13;
            foreach (contourInfo pIno in orderedList)
            {
                if (viewText.Length > 0)
                    Debug.WriteLine(String.Format("RUN]{0} LAST={1},{2} CUR={3},{4},{5}", viewText, prevX, prevWidth, pIno.x, pIno.width, pIno.Text));
                // RUN]:3step55m LAST=131,16 CUR=151,7,i
                // RUN]:3step55mi LAST = 151,7 CUR = 153,4,:
                // RUN]:3step55mi: LAST = 153,4 CUR = 163,16,n
                // RUN]10: LAST=79,6 CUR=79,6,:                RUN]10: LAST = 79,6 CUR = 137,21,0
                //if ((prevX > pIno.x) && ((prevX + prevWidth) >= pIno.x))
                //if(Math.Abs(prevX + prevWidth - pIno.x + pIno.width) < 2)
                //if ((prevX + prevWidth) > pIno.x)
                if((prevX + prevWidth) >= (pIno.x + pIno.width))
                {

                }
                else
                {
                    if ((pIno.x - (prevX + prevWidth) > spaceLen) && (viewText.Length > 0))
                    {
                        viewText += " ";
                    }
                    viewText += pIno.Text;
                }

                prevX = pIno.x;
                prevWidth = pIno.width;
            }
            Debug.WriteLine(String.Format("########### ORDERED]{0}={1} TYPE={2}", viewText, viewText.Length, ocrType));
            if (viewText.Length > 0)
            {
                //ocrString = viewText;
                if (ocrType == OCR_TYPE_FLOAT)
                {
                    ocrString = viewText.Replace(":", ".").Replace(" ", "");
                    if (ocrString.Length > 8)
                        ocrString = "";
                }
                else if (ocrType == OCR_TYPE_DIGIT)
                {
                    ocrString = viewText.Replace(":", "").Replace(" ", "");
                    if (ocrString.Length > 8)
                        ocrString = "";
                }
                else
                    ocrString = viewText.Replace("::", ":");
            }

            return (ocrString);
        }

        public String DoOCR2(Mat grayMat, int ocrType, bool bSmallSize = false, int splitPoint = 0)
        {
            String ocrString = "";
            OCR_STRING = "";

            var orderedList = runContours(grayMat, ocrType, false);

            //var orderedList = pListText.OrderBy(s => s.x);
            int prevX = -1000, prevWidth = 0;
            String viewText = "";
            int spaceLen = 22;
            if (ocrType == OCR_TYPE_TEXT)
                spaceLen = 13;
            bool splitSet = false;
            int insertCharPoint = -1;
            foreach (contourInfo pIno in orderedList)
            {
                if (viewText.Length > 0)
                    Debug.WriteLine(String.Format("RUN]{0} LAST={1},{2} CUR={3},{4},{5}", viewText, prevX, prevWidth, pIno.x, pIno.width, pIno.Text));
                // RUN]:3step55m LAST=131,16 CUR=151,7,i
                // RUN]:3step55mi LAST = 151,7 CUR = 153,4,:
                // RUN]:3step55mi: LAST = 153,4 CUR = 163,16,n
                // RUN]10: LAST=79,6 CUR=79,6,:                RUN]10: LAST = 79,6 CUR = 137,21,0
                //if ((prevX > pIno.x) && ((prevX + prevWidth) >= pIno.x))
                //if(Math.Abs(prevX + prevWidth - pIno.x + pIno.width) < 2)
                //if ((prevX + prevWidth) > pIno.x)
                if ((splitPoint > 0) && (pIno.x > splitPoint) && (splitSet == false))
                {
                    splitSet = true;
                    insertCharPoint = viewText.Length;
                    //viewText += "$$$$";
                }
                if ((prevX + prevWidth) >= (pIno.x + pIno.width))
                {

                }
                else
                {
                    if ((pIno.x - (prevX + prevWidth) > spaceLen) && (viewText.Length > 0))
                    {
                        viewText += " ";
                    }
                    viewText += pIno.Text;
                }

                prevX = pIno.x;
                prevWidth = pIno.width;
            }
            Debug.WriteLine(String.Format("########### ORDERED]{0}={1} TYPE={2}", viewText, viewText.Length, ocrType));
            if (viewText.Length > 0)
            {
                //ocrString = viewText;
                if (ocrType == OCR_TYPE_FLOAT)
                {
                    ocrString = viewText.Replace(":", ".").Replace(" ", "");
                    if (ocrString.Length > 8)
                        ocrString = "";
                }
                else if (ocrType == OCR_TYPE_DIGIT)
                {
                    ocrString = viewText.Replace(":", "").Replace(" ", "");
                    if (ocrString.Length > 8)
                        ocrString = "";
                }
                else
                    ocrString = viewText.Replace("::", ":");
                if((ocrString.Length > insertCharPoint) && (insertCharPoint >= 0))
                {
                    if (insertCharPoint == 0)
                        ocrString = "$$$" + ocrString;
                    else
                    {
                        viewText = ocrString.Substring(0, insertCharPoint).Trim() + "$$$" + ocrString.Substring(insertCharPoint).Trim();
                        ocrString = viewText;
                    }
                }
            }

            return (ocrString);
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////
        /// OCR MAIN
        /////////////////////////////////////////////////////////////////////////////////////////////////
        private bool m_bDoubleOcrEnable = false;
        public void OcrDoWindow(String fileName, Object objJasonList, int nWidth, int nHeight)
        {
            if (System.IO.File.Exists(fileName) == false)
            {
                Debug.WriteLine("OcrDoWindow] NOT EXISTS=" + fileName);
                return;
            }
            System.Diagnostics.Stopwatch sw = new Stopwatch();
            sw.Start();
            var imgOrg = Cv2.ImRead(fileName);
            //Cv2.ImShow(fileName, imgOrg);
            if ((imgOrg.Width < 100) || (imgOrg.Height < 100))
            {
                Debug.WriteLine("OcrDoWindow] TOO SMALL=" + imgOrg.Width);
                return;
            }
            //findEdge(imgOrg);
            findEdge(fileName);
            if(m_bBasePointFound == false)
            {
                Debug.WriteLine("OcrDoWindow] FAIL to Find Edge=" + imgOrg.Width);
                return;
            }
            if(((m_pBasePoint.X + nWidth) > imgOrg.Width) || ((m_pBasePoint.Y + nHeight) > imgOrg.Height))
            {
                Debug.WriteLine("OcrDoWindow] TOO SMALL IMAGE=" + imgOrg.Width);
                return;
            }
            OpenCvSharp.Rect rect = new OpenCvSharp.Rect(m_pBasePoint.X, m_pBasePoint.Y, nWidth, nHeight);
            Mat imgCrop = imgOrg.SubMat(rect);
            if (nWidth < 1000)
            {
                Mat imgResize = imgOrg.SubMat(rect);
                //Cv2.Resize(imgResize, imgCrop, new OpenCvSharp.Size(nWidth * 2, nHeight * 2)); // JUNG CODE
                Cv2.Resize(imgResize, imgCrop, new OpenCvSharp.Size(nWidth * 2, nHeight * 1));
            }
            Mat imgRun = new Mat();
            Mat imgGray = new Mat();
            Cv2.CvtColor(imgCrop, imgGray, ColorConversionCodes.BGRA2GRAY);
            Cv2.CvtColor(imgCrop, imgRun, ColorConversionCodes.BGRA2GRAY);

            var threshImage = new Mat();
            Cv2.Threshold(imgGray, threshImage, Thresh, ThresholdMaxVal,
                ThresholdTypes.Binary | ThresholdTypes.Otsu); //ThresholdTypes.BinaryInv // Threshold to find contour

            Mat matBitWise = new Mat();
            Cv2.BitwiseAnd(threshImage, threshImage, matBitWise, threshImage);
            threshImage = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);
            imgGray = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);
            Mat imgClone = imgCrop.Clone();

            //Cv2.ImShow("Crop", imgCrop);
            var jsonList = objJasonList as List<jasonOcrRect>;
            Debug.WriteLine("####### items=" + jsonList.Count + String.Format(", GRAY={0},{1}", imgGray.Width, imgGray.Height));
            foreach (var pItem in jsonList)
            {
                pItem.ocrRun = false;
            }
            foreach (var pItem in jsonList)
            {
                if (pItem.ocrRun == true)
                    continue;
                pItem.ocrRun = true;
                Cv2.Rectangle(imgClone, new Rect(pItem.X, pItem.Y, pItem.Width, pItem.Height), Scalar.Yellow, 1, LineTypes.AntiAlias);
                var pRunRect = new OpenCvSharp.Rect(pItem.X, pItem.Y, pItem.Width, pItem.Height);
                int splitX = 0;
                if (pItem.Name.IndexOf("-SET") > 0)
                {
                    var monName = pItem.Name.Replace("-SET", "-MON");
                    var monItem = jsonList.Find(s => s.Name.Equals(monName));
                    Debug.WriteLine(String.Format("\t==>SET]{0} <=={1}", monName, pItem.Name));
                    if (monItem != null)
                    {
                        Debug.WriteLine("\t--->MON ITEM]" + monItem.Name);
                        if (m_bDoubleOcrEnable == true)
                        {
                            Cv2.Rectangle(imgClone, new Rect(monItem.X, monItem.Y, monItem.Width, monItem.Height), Scalar.Yellow, 1, LineTypes.AntiAlias);
                            pRunRect.Width = monItem.X - pItem.X + monItem.Width;
                            monItem.ocrRun = true;
                            splitX = monItem.X - pItem.X;
                        }
                    }
                }

                Debug.WriteLine(String.Format("ITEM]{0}={1},{2},{3},{4}", pItem.Name, pItem.X, pItem.Y, pItem.Width, pItem.Height));
                Mat imgOCR = new Mat();
                imgOCR = imgRun.SubMat(pRunRect);
                String ocrMessaege = DoOCR2(imgOCR, pItem.Type, splitPoint:splitX);
                if ((ocrMessaege.Length > 0) && (splitX > 0))
                {
                    ocrMessaege += String.Format("<--{0},{1}", m_nOcrContourTotal, m_nOcrContourRun);
                }
                if (ocrMessaege.Length > 0)
                {
                    Cv2.PutText(imgClone, ocrMessaege,
                                new OpenCvSharp.Point(pItem.X + pItem.Width + 2, pItem.Y + 12),
                                HersheyFonts.HersheyPlain, 0.8, Scalar.Yellow);
                }
            }
            sw.Stop();
            //imgClone.Resize(2);
            Cv2.ImShow(String.Format("Detected] ELAPSE={0}", (int)sw.ElapsedMilliseconds), imgClone);
        }

        public void OcrDo(String fileName, Object objJasonList, int nWidth, int nHeight)
        {
            m_bOcrResult = false;
            m_OCR_ERROR = "";
            if (System.IO.File.Exists(fileName) == false)
            {
                Debug.WriteLine("OcrDoWindow] NOT EXISTS=" + fileName);
                return;
            }
            var imgOrg = Cv2.ImRead(fileName);
            //Cv2.ImShow(fileName, imgOrg);
            if ((imgOrg.Width < 100) || (imgOrg.Height < 100))
            {
                Debug.WriteLine("OcrDoWindow] TOO SMALL=" + imgOrg.Width);
                return;
            }
            //findEdge(imgOrg);
            if (m_bBasePointFound == false)
            {
                Debug.WriteLine("OcrDoWindow] FAIL to Find Edge=" + imgOrg.Width);
                return;
            }
            if (((m_pBasePoint.X + nWidth) > imgOrg.Width) || ((m_pBasePoint.Y + nHeight) > imgOrg.Height))
            {
                Debug.WriteLine("OcrDoWindow] TOO SMALL IMAGE=" + imgOrg.Width);
                return;
            }
            OpenCvSharp.Rect rect = new OpenCvSharp.Rect(m_pBasePoint.X, m_pBasePoint.Y, nWidth, nHeight);
            Mat imgCrop = imgOrg.SubMat(rect);
            if (nWidth < 1000)
            {
                Mat imgResize = imgOrg.SubMat(rect);
                //Cv2.Resize(imgResize, imgCrop, new OpenCvSharp.Size(nWidth * 2, nHeight * 2)); // JUNG CODE
                Cv2.Resize(imgResize, imgCrop, new OpenCvSharp.Size(nWidth * 2, nHeight * 1));
            }
            Mat ImgGRAY = new Mat();
            Cv2.CvtColor(imgCrop, ImgGRAY, ColorConversionCodes.BGRA2GRAY);
            Mat imgRun = new Mat();
            Cv2.CvtColor(imgCrop, imgRun, ColorConversionCodes.BGRA2GRAY);

            var threshImage = new Mat();
            Cv2.Threshold(ImgGRAY, threshImage, Thresh, ThresholdMaxVal,
                ThresholdTypes.Binary | ThresholdTypes.Otsu); //ThresholdTypes.BinaryInv // Threshold to find contour
            m_ImgGray = BitmapConverter.ToBitmap(threshImage);

            Mat matBitWise = new Mat();
            Cv2.BitwiseAnd(threshImage, threshImage, matBitWise, threshImage);
            threshImage = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);
            ImgGRAY = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);
            m_bOcrResult = true;
            //m_ImgGray = BitmapConverter.ToBitmap(ImgGRAY);

            //Cv2.ImShow("Crop", imgCrop);
            var jsonList = objJasonList as List<jasonOcrRect>;
            Debug.WriteLine("####### items=" + jsonList.Count + String.Format(", GRAY={0},{1}", ImgGRAY.Width, ImgGRAY.Height));
            foreach (var pItem in jsonList)
            {
                pItem.ocrRun = false;
                pItem.DataValid = true;
            }
            int nCount = 0;
            foreach (var pItem in jsonList)
            {
                nCount++;
                if (pItem.ocrRun == true)
                    continue;
                pItem.ocrRun = true;
                Debug.WriteLine(String.Format("ITEM]{0}={1},{2},{3},{4}", pItem.Name, pItem.X, pItem.Y, pItem.Width, pItem.Height));
                Mat imgOCR = new Mat();
                var pRunRect = new OpenCvSharp.Rect(pItem.X, pItem.Y, pItem.Width, pItem.Height);
                int splitX = 0, nMonIdx = -1;
                if (pItem.Name.IndexOf("-SET") > 0)
                {
                    var monName = pItem.Name.Replace("-SET", "-MON");
                    for (int n = nCount; n < jsonList.Count; n++)
                    {
                        if (jsonList[n].Name == monName)
                        {
                            if (m_bDoubleOcrEnable == true)
                            {
                                pRunRect.Width = jsonList[n].X - pItem.X + jsonList[n].Width;
                                jsonList[n].ocrRun = true;
                                splitX = jsonList[n].X - pItem.X;
                                nMonIdx = n;
                            }
                            break;
                        }
                    }
                }
                imgOCR = imgRun.SubMat(pRunRect);
                String ocrMessaege = DoOCR2(imgOCR, pItem.Type, splitPoint:splitX);
                String[] splitVal = ocrMessaege.Replace("$$$","\t").Split('\t');
                if (pItem.Verify.Length > 0)
                {
                    if (pItem.Verify != ocrMessaege)
                    {
                        m_OCR_ERROR += String.Format("{0}={1}\t", pItem.Name, ocrMessaege);
                        pItem.DataValid = false;
                    }
                }
                else if ((nMonIdx > 0) && (splitVal.Length == 2))
                {
                    pItem.DataOCR0 = splitVal[0];
                    if (pItem.DataOCR0.Length > 0)
                    {
                        if (pItem.Type == OCR_TYPE_DIGIT)
                        {
                            int nVal;
                            if (int.TryParse(pItem.DataOCR0, out nVal) == false)
                            {
                                pItem.DataValid = false;
                                m_OCR_ERROR += String.Format("{0}={1}\t", pItem.Name, pItem.DataOCR0);
                            }
                        }
                        else if (pItem.Type == OCR_TYPE_FLOAT)
                        {
                            double nVal;
                            if (double.TryParse(pItem.DataOCR0, out nVal) == false)
                            {
                                pItem.DataValid = false;
                                m_OCR_ERROR += String.Format("{0}={1}\t", pItem.Name, pItem.DataOCR0);
                            }
                        }
                    }

                    // set MON value
                    jsonList[nMonIdx].DataOCR0 = splitVal[1];
                    if (jsonList[nMonIdx].DataOCR0.Length > 0)
                    {
                        if (pItem.Type == OCR_TYPE_DIGIT)
                        {
                            int nVal;
                            if (int.TryParse(jsonList[nMonIdx].DataOCR0, out nVal) == false)
                            {
                                jsonList[nMonIdx].DataValid = false;
                                m_OCR_ERROR += String.Format("{0}={1}\t", jsonList[nMonIdx].Name, jsonList[nMonIdx].DataOCR0);
                            }
                        }
                        else if (pItem.Type == OCR_TYPE_FLOAT)
                        {
                            double nVal;
                            if (double.TryParse(jsonList[nMonIdx].DataOCR0, out nVal) == false)
                            {
                                jsonList[nMonIdx].DataValid = false;
                                m_OCR_ERROR += String.Format("{0}={1}\t", jsonList[nMonIdx].Name, jsonList[nMonIdx].DataOCR0);
                            }
                        }
                    }
                }
                else
                {
                    if (pItem.Name == "STEP")
                    {
                        String[] strSplits = ocrMessaege.Split('/');
                        if (strSplits.Length == 2)
                        {
                            pItem.DataOCR0 = strSplits[0];
                            pItem.DataOCR1 = strSplits[1];
                        }
                        else
                        {
                            pItem.DataValid = false;
                            m_OCR_ERROR += String.Format("{0}={1}\t", pItem.Name, ocrMessaege);
                        }
                    }
                    else
                    {
                        pItem.DataOCR0 = ocrMessaege;
                        if (ocrMessaege.Length > 0)
                        {
                            if (pItem.Type == OCR_TYPE_DIGIT)
                            {
                                int nVal;
                                if (int.TryParse(ocrMessaege, out nVal) == false)
                                {
                                    pItem.DataValid = false;
                                    m_OCR_ERROR += String.Format("{0}={1}\t", pItem.Name, ocrMessaege);
                                }
                            }
                            else if (pItem.Type == OCR_TYPE_FLOAT)
                            {
                                double nVal;
                                if (double.TryParse(ocrMessaege, out nVal) == false)
                                {
                                    pItem.DataValid = false;
                                    m_OCR_ERROR += String.Format("{0}={1}\t", pItem.Name, ocrMessaege);
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public class jasonOcrRect
    {
        public String Name { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }
        public int Type { get; set; }
        public int Line { get; set; }
        public int Step { get; set; }
        public String Verify { get; set; }

        public bool ocrRun { get; set; }
        public bool DataValid { get; set; }
        public String DataOCR0 { get; set; }
        public String DataOCR1 { get; set; } // for step
    }
}
