﻿namespace enCaptureUltima3
{
    partial class ultima2View
    {
        /// <summary> 
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 구성 요소 디자이너에서 생성한 코드

        /// <summary> 
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRUN = new System.Windows.Forms.Label();
            this.picSHOW = new System.Windows.Forms.PictureBox();
            this.picSTREAM = new System.Windows.Forms.PictureBox();
            this.ln1_AutoIdle = new System.Windows.Forms.Label();
            this.ln1_PPID = new System.Windows.Forms.Label();
            this.ln2_PressSet = new System.Windows.Forms.Label();
            this.ln2_PressMon = new System.Windows.Forms.Label();
            this.ln2_Step_Total = new System.Windows.Forms.Label();
            this.ln3_ValveMon = new System.Windows.Forms.Label();
            this.ln3_ValveSet = new System.Windows.Forms.Label();
            this.ln3_RF_MON = new System.Windows.Forms.Label();
            this.ln3_RF_SET = new System.Windows.Forms.Label();
            this.ln3_RFr_MON = new System.Windows.Forms.Label();
            this.ln3_RFr_SET = new System.Windows.Forms.Label();
            this.ln4_Gas2_MON = new System.Windows.Forms.Label();
            this.ln4_Gas2_SET = new System.Windows.Forms.Label();
            this.ln4_Gas1_MON = new System.Windows.Forms.Label();
            this.ln4_Gas1_SET = new System.Windows.Forms.Label();
            this.ln8_Temp3_MON = new System.Windows.Forms.Label();
            this.ln8_Temp3_SET = new System.Windows.Forms.Label();
            this.ln7_Temp2_MON = new System.Windows.Forms.Label();
            this.ln7_Temp2_SET = new System.Windows.Forms.Label();
            this.ln6_Temp1_MON = new System.Windows.Forms.Label();
            this.ln6_Temp1_SET = new System.Windows.Forms.Label();
            this.ln9_EPD_MON = new System.Windows.Forms.Label();
            this.ln9_EPD_SET = new System.Windows.Forms.Label();
            this.ln10_TIME_SET = new System.Windows.Forms.Label();
            this.ln10_TIME_MON = new System.Windows.Forms.Label();
            this.ln11_CYCLE_MON = new System.Windows.Forms.Label();
            this.ln11_CYCLE_SET = new System.Windows.Forms.Label();
            this.ln11_CYCLE_STEP = new System.Windows.Forms.Label();
            this.ln11_CYCLE_TEXT = new System.Windows.Forms.Label();
            this.ln2_Step_Cur = new System.Windows.Forms.Label();
            this.lblTIME = new System.Windows.Forms.Label();
            this.checkView = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.picSHOW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSTREAM)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRUN
            // 
            this.lblRUN.Location = new System.Drawing.Point(13, 17);
            this.lblRUN.Name = "lblRUN";
            this.lblRUN.Size = new System.Drawing.Size(278, 23);
            this.lblRUN.TabIndex = 0;
            this.lblRUN.Text = "label1";
            this.lblRUN.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // picSHOW
            // 
            this.picSHOW.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picSHOW.Location = new System.Drawing.Point(13, 48);
            this.picSHOW.Name = "picSHOW";
            this.picSHOW.Size = new System.Drawing.Size(509, 290);
            this.picSHOW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSHOW.TabIndex = 1;
            this.picSHOW.TabStop = false;
            // 
            // picSTREAM
            // 
            this.picSTREAM.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.picSTREAM.Location = new System.Drawing.Point(445, 5);
            this.picSTREAM.Name = "picSTREAM";
            this.picSTREAM.Size = new System.Drawing.Size(77, 35);
            this.picSTREAM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picSTREAM.TabIndex = 2;
            this.picSTREAM.TabStop = false;
            // 
            // ln1_AutoIdle
            // 
            this.ln1_AutoIdle.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln1_AutoIdle.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln1_AutoIdle.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln1_AutoIdle.Location = new System.Drawing.Point(13, 353);
            this.ln1_AutoIdle.Name = "ln1_AutoIdle";
            this.ln1_AutoIdle.Size = new System.Drawing.Size(114, 24);
            this.ln1_AutoIdle.TabIndex = 3;
            this.ln1_AutoIdle.Text = "auto-idle";
            this.ln1_AutoIdle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln1_PPID
            // 
            this.ln1_PPID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln1_PPID.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln1_PPID.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln1_PPID.Location = new System.Drawing.Point(136, 353);
            this.ln1_PPID.Name = "ln1_PPID";
            this.ln1_PPID.Size = new System.Drawing.Size(155, 24);
            this.ln1_PPID.TabIndex = 4;
            this.ln1_PPID.Text = "auto-idle";
            this.ln1_PPID.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln2_PressSet
            // 
            this.ln2_PressSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln2_PressSet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln2_PressSet.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln2_PressSet.Location = new System.Drawing.Point(13, 394);
            this.ln2_PressSet.Name = "ln2_PressSet";
            this.ln2_PressSet.Size = new System.Drawing.Size(54, 24);
            this.ln2_PressSet.TabIndex = 5;
            this.ln2_PressSet.Text = "99990";
            this.ln2_PressSet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln2_PressMon
            // 
            this.ln2_PressMon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln2_PressMon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln2_PressMon.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln2_PressMon.Location = new System.Drawing.Point(73, 394);
            this.ln2_PressMon.Name = "ln2_PressMon";
            this.ln2_PressMon.Size = new System.Drawing.Size(54, 24);
            this.ln2_PressMon.TabIndex = 6;
            this.ln2_PressMon.Text = "99990";
            this.ln2_PressMon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln2_Step_Total
            // 
            this.ln2_Step_Total.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln2_Step_Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln2_Step_Total.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln2_Step_Total.Location = new System.Drawing.Point(420, 394);
            this.ln2_Step_Total.Name = "ln2_Step_Total";
            this.ln2_Step_Total.Size = new System.Drawing.Size(54, 24);
            this.ln2_Step_Total.TabIndex = 7;
            this.ln2_Step_Total.Text = "99990";
            this.ln2_Step_Total.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln3_ValveMon
            // 
            this.ln3_ValveMon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln3_ValveMon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln3_ValveMon.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln3_ValveMon.Location = new System.Drawing.Point(73, 433);
            this.ln3_ValveMon.Name = "ln3_ValveMon";
            this.ln3_ValveMon.Size = new System.Drawing.Size(54, 24);
            this.ln3_ValveMon.TabIndex = 9;
            this.ln3_ValveMon.Text = "99990";
            this.ln3_ValveMon.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln3_ValveSet
            // 
            this.ln3_ValveSet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln3_ValveSet.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln3_ValveSet.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln3_ValveSet.Location = new System.Drawing.Point(13, 433);
            this.ln3_ValveSet.Name = "ln3_ValveSet";
            this.ln3_ValveSet.Size = new System.Drawing.Size(54, 24);
            this.ln3_ValveSet.TabIndex = 8;
            this.ln3_ValveSet.Text = "99990";
            this.ln3_ValveSet.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln3_RF_MON
            // 
            this.ln3_RF_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln3_RF_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln3_RF_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln3_RF_MON.Location = new System.Drawing.Point(252, 433);
            this.ln3_RF_MON.Name = "ln3_RF_MON";
            this.ln3_RF_MON.Size = new System.Drawing.Size(54, 24);
            this.ln3_RF_MON.TabIndex = 11;
            this.ln3_RF_MON.Text = "99990";
            this.ln3_RF_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln3_RF_SET
            // 
            this.ln3_RF_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln3_RF_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln3_RF_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln3_RF_SET.Location = new System.Drawing.Point(192, 433);
            this.ln3_RF_SET.Name = "ln3_RF_SET";
            this.ln3_RF_SET.Size = new System.Drawing.Size(54, 24);
            this.ln3_RF_SET.TabIndex = 10;
            this.ln3_RF_SET.Text = "99990";
            this.ln3_RF_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln3_RFr_MON
            // 
            this.ln3_RFr_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln3_RFr_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln3_RFr_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln3_RFr_MON.Location = new System.Drawing.Point(420, 433);
            this.ln3_RFr_MON.Name = "ln3_RFr_MON";
            this.ln3_RFr_MON.Size = new System.Drawing.Size(54, 24);
            this.ln3_RFr_MON.TabIndex = 13;
            this.ln3_RFr_MON.Text = "99990";
            this.ln3_RFr_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln3_RFr_SET
            // 
            this.ln3_RFr_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln3_RFr_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln3_RFr_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln3_RFr_SET.Location = new System.Drawing.Point(360, 433);
            this.ln3_RFr_SET.Name = "ln3_RFr_SET";
            this.ln3_RFr_SET.Size = new System.Drawing.Size(54, 24);
            this.ln3_RFr_SET.TabIndex = 12;
            this.ln3_RFr_SET.Text = "99990";
            this.ln3_RFr_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln4_Gas2_MON
            // 
            this.ln4_Gas2_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln4_Gas2_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln4_Gas2_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln4_Gas2_MON.Location = new System.Drawing.Point(252, 468);
            this.ln4_Gas2_MON.Name = "ln4_Gas2_MON";
            this.ln4_Gas2_MON.Size = new System.Drawing.Size(54, 24);
            this.ln4_Gas2_MON.TabIndex = 17;
            this.ln4_Gas2_MON.Text = "99990";
            this.ln4_Gas2_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln4_Gas2_SET
            // 
            this.ln4_Gas2_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln4_Gas2_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln4_Gas2_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln4_Gas2_SET.Location = new System.Drawing.Point(192, 468);
            this.ln4_Gas2_SET.Name = "ln4_Gas2_SET";
            this.ln4_Gas2_SET.Size = new System.Drawing.Size(54, 24);
            this.ln4_Gas2_SET.TabIndex = 16;
            this.ln4_Gas2_SET.Text = "99990";
            this.ln4_Gas2_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln4_Gas1_MON
            // 
            this.ln4_Gas1_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln4_Gas1_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln4_Gas1_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln4_Gas1_MON.Location = new System.Drawing.Point(73, 468);
            this.ln4_Gas1_MON.Name = "ln4_Gas1_MON";
            this.ln4_Gas1_MON.Size = new System.Drawing.Size(54, 24);
            this.ln4_Gas1_MON.TabIndex = 15;
            this.ln4_Gas1_MON.Text = "99990";
            this.ln4_Gas1_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln4_Gas1_SET
            // 
            this.ln4_Gas1_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln4_Gas1_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln4_Gas1_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln4_Gas1_SET.Location = new System.Drawing.Point(13, 468);
            this.ln4_Gas1_SET.Name = "ln4_Gas1_SET";
            this.ln4_Gas1_SET.Size = new System.Drawing.Size(54, 24);
            this.ln4_Gas1_SET.TabIndex = 14;
            this.ln4_Gas1_SET.Text = "99990";
            this.ln4_Gas1_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln8_Temp3_MON
            // 
            this.ln8_Temp3_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln8_Temp3_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln8_Temp3_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln8_Temp3_MON.Location = new System.Drawing.Point(420, 501);
            this.ln8_Temp3_MON.Name = "ln8_Temp3_MON";
            this.ln8_Temp3_MON.Size = new System.Drawing.Size(54, 24);
            this.ln8_Temp3_MON.TabIndex = 23;
            this.ln8_Temp3_MON.Text = "99990";
            this.ln8_Temp3_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln8_Temp3_SET
            // 
            this.ln8_Temp3_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln8_Temp3_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln8_Temp3_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln8_Temp3_SET.Location = new System.Drawing.Point(360, 501);
            this.ln8_Temp3_SET.Name = "ln8_Temp3_SET";
            this.ln8_Temp3_SET.Size = new System.Drawing.Size(54, 24);
            this.ln8_Temp3_SET.TabIndex = 22;
            this.ln8_Temp3_SET.Text = "99990";
            this.ln8_Temp3_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln7_Temp2_MON
            // 
            this.ln7_Temp2_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln7_Temp2_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln7_Temp2_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln7_Temp2_MON.Location = new System.Drawing.Point(252, 501);
            this.ln7_Temp2_MON.Name = "ln7_Temp2_MON";
            this.ln7_Temp2_MON.Size = new System.Drawing.Size(54, 24);
            this.ln7_Temp2_MON.TabIndex = 21;
            this.ln7_Temp2_MON.Text = "99990";
            this.ln7_Temp2_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln7_Temp2_SET
            // 
            this.ln7_Temp2_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln7_Temp2_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln7_Temp2_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln7_Temp2_SET.Location = new System.Drawing.Point(192, 501);
            this.ln7_Temp2_SET.Name = "ln7_Temp2_SET";
            this.ln7_Temp2_SET.Size = new System.Drawing.Size(54, 24);
            this.ln7_Temp2_SET.TabIndex = 20;
            this.ln7_Temp2_SET.Text = "99990";
            this.ln7_Temp2_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln6_Temp1_MON
            // 
            this.ln6_Temp1_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln6_Temp1_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln6_Temp1_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln6_Temp1_MON.Location = new System.Drawing.Point(73, 501);
            this.ln6_Temp1_MON.Name = "ln6_Temp1_MON";
            this.ln6_Temp1_MON.Size = new System.Drawing.Size(54, 24);
            this.ln6_Temp1_MON.TabIndex = 19;
            this.ln6_Temp1_MON.Text = "99990";
            this.ln6_Temp1_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln6_Temp1_SET
            // 
            this.ln6_Temp1_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln6_Temp1_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln6_Temp1_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln6_Temp1_SET.Location = new System.Drawing.Point(13, 501);
            this.ln6_Temp1_SET.Name = "ln6_Temp1_SET";
            this.ln6_Temp1_SET.Size = new System.Drawing.Size(54, 24);
            this.ln6_Temp1_SET.TabIndex = 18;
            this.ln6_Temp1_SET.Text = "99990";
            this.ln6_Temp1_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln9_EPD_MON
            // 
            this.ln9_EPD_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln9_EPD_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln9_EPD_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln9_EPD_MON.Location = new System.Drawing.Point(73, 535);
            this.ln9_EPD_MON.Name = "ln9_EPD_MON";
            this.ln9_EPD_MON.Size = new System.Drawing.Size(54, 24);
            this.ln9_EPD_MON.TabIndex = 25;
            this.ln9_EPD_MON.Text = "99990";
            this.ln9_EPD_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln9_EPD_SET
            // 
            this.ln9_EPD_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln9_EPD_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln9_EPD_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln9_EPD_SET.Location = new System.Drawing.Point(13, 535);
            this.ln9_EPD_SET.Name = "ln9_EPD_SET";
            this.ln9_EPD_SET.Size = new System.Drawing.Size(54, 24);
            this.ln9_EPD_SET.TabIndex = 24;
            this.ln9_EPD_SET.Text = "99990";
            this.ln9_EPD_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln10_TIME_SET
            // 
            this.ln10_TIME_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln10_TIME_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln10_TIME_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln10_TIME_SET.Location = new System.Drawing.Point(182, 535);
            this.ln10_TIME_SET.Name = "ln10_TIME_SET";
            this.ln10_TIME_SET.Size = new System.Drawing.Size(64, 24);
            this.ln10_TIME_SET.TabIndex = 26;
            this.ln10_TIME_SET.Text = "99990";
            this.ln10_TIME_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln10_TIME_MON
            // 
            this.ln10_TIME_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln10_TIME_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln10_TIME_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln10_TIME_MON.Location = new System.Drawing.Point(252, 535);
            this.ln10_TIME_MON.Name = "ln10_TIME_MON";
            this.ln10_TIME_MON.Size = new System.Drawing.Size(64, 24);
            this.ln10_TIME_MON.TabIndex = 27;
            this.ln10_TIME_MON.Text = "99990";
            this.ln10_TIME_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln11_CYCLE_MON
            // 
            this.ln11_CYCLE_MON.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln11_CYCLE_MON.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln11_CYCLE_MON.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln11_CYCLE_MON.Location = new System.Drawing.Point(73, 568);
            this.ln11_CYCLE_MON.Name = "ln11_CYCLE_MON";
            this.ln11_CYCLE_MON.Size = new System.Drawing.Size(54, 24);
            this.ln11_CYCLE_MON.TabIndex = 29;
            this.ln11_CYCLE_MON.Text = "99990";
            this.ln11_CYCLE_MON.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln11_CYCLE_SET
            // 
            this.ln11_CYCLE_SET.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln11_CYCLE_SET.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln11_CYCLE_SET.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln11_CYCLE_SET.Location = new System.Drawing.Point(13, 568);
            this.ln11_CYCLE_SET.Name = "ln11_CYCLE_SET";
            this.ln11_CYCLE_SET.Size = new System.Drawing.Size(54, 24);
            this.ln11_CYCLE_SET.TabIndex = 28;
            this.ln11_CYCLE_SET.Text = "99990";
            this.ln11_CYCLE_SET.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln11_CYCLE_STEP
            // 
            this.ln11_CYCLE_STEP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln11_CYCLE_STEP.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln11_CYCLE_STEP.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln11_CYCLE_STEP.Location = new System.Drawing.Point(420, 568);
            this.ln11_CYCLE_STEP.Name = "ln11_CYCLE_STEP";
            this.ln11_CYCLE_STEP.Size = new System.Drawing.Size(54, 24);
            this.ln11_CYCLE_STEP.TabIndex = 30;
            this.ln11_CYCLE_STEP.Text = "99990";
            this.ln11_CYCLE_STEP.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln11_CYCLE_TEXT
            // 
            this.ln11_CYCLE_TEXT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln11_CYCLE_TEXT.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln11_CYCLE_TEXT.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln11_CYCLE_TEXT.Location = new System.Drawing.Point(192, 568);
            this.ln11_CYCLE_TEXT.Name = "ln11_CYCLE_TEXT";
            this.ln11_CYCLE_TEXT.Size = new System.Drawing.Size(114, 24);
            this.ln11_CYCLE_TEXT.TabIndex = 31;
            this.ln11_CYCLE_TEXT.Text = "99990";
            this.ln11_CYCLE_TEXT.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // ln2_Step_Cur
            // 
            this.ln2_Step_Cur.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ln2_Step_Cur.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.ln2_Step_Cur.Font = new System.Drawing.Font("굴림", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.ln2_Step_Cur.Location = new System.Drawing.Point(360, 394);
            this.ln2_Step_Cur.Name = "ln2_Step_Cur";
            this.ln2_Step_Cur.Size = new System.Drawing.Size(54, 24);
            this.ln2_Step_Cur.TabIndex = 32;
            this.ln2_Step_Cur.Text = "99990";
            this.ln2_Step_Cur.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblTIME
            // 
            this.lblTIME.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lblTIME.Font = new System.Drawing.Font("굴림", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.lblTIME.Location = new System.Drawing.Point(319, 353);
            this.lblTIME.Name = "lblTIME";
            this.lblTIME.Size = new System.Drawing.Size(203, 24);
            this.lblTIME.TabIndex = 33;
            this.lblTIME.Text = "auto-idle";
            this.lblTIME.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // checkView
            // 
            this.checkView.AutoSize = true;
            this.checkView.Location = new System.Drawing.Point(333, 21);
            this.checkView.Name = "checkView";
            this.checkView.Size = new System.Drawing.Size(81, 16);
            this.checkView.TabIndex = 34;
            this.checkView.Text = "View Text";
            this.checkView.UseVisualStyleBackColor = true;
            // 
            // ultima2View
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.Color.DimGray;
            this.Controls.Add(this.checkView);
            this.Controls.Add(this.lblTIME);
            this.Controls.Add(this.ln2_Step_Cur);
            this.Controls.Add(this.ln11_CYCLE_TEXT);
            this.Controls.Add(this.ln11_CYCLE_STEP);
            this.Controls.Add(this.ln11_CYCLE_MON);
            this.Controls.Add(this.ln11_CYCLE_SET);
            this.Controls.Add(this.ln10_TIME_MON);
            this.Controls.Add(this.ln10_TIME_SET);
            this.Controls.Add(this.ln9_EPD_MON);
            this.Controls.Add(this.ln9_EPD_SET);
            this.Controls.Add(this.ln8_Temp3_MON);
            this.Controls.Add(this.ln8_Temp3_SET);
            this.Controls.Add(this.ln7_Temp2_MON);
            this.Controls.Add(this.ln7_Temp2_SET);
            this.Controls.Add(this.ln6_Temp1_MON);
            this.Controls.Add(this.ln6_Temp1_SET);
            this.Controls.Add(this.ln4_Gas2_MON);
            this.Controls.Add(this.ln4_Gas2_SET);
            this.Controls.Add(this.ln4_Gas1_MON);
            this.Controls.Add(this.ln4_Gas1_SET);
            this.Controls.Add(this.ln3_RFr_MON);
            this.Controls.Add(this.ln3_RFr_SET);
            this.Controls.Add(this.ln3_RF_MON);
            this.Controls.Add(this.ln3_RF_SET);
            this.Controls.Add(this.ln3_ValveMon);
            this.Controls.Add(this.ln3_ValveSet);
            this.Controls.Add(this.ln2_Step_Total);
            this.Controls.Add(this.ln2_PressMon);
            this.Controls.Add(this.ln2_PressSet);
            this.Controls.Add(this.ln1_PPID);
            this.Controls.Add(this.ln1_AutoIdle);
            this.Controls.Add(this.picSTREAM);
            this.Controls.Add(this.picSHOW);
            this.Controls.Add(this.lblRUN);
            this.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.Name = "ultima2View";
            this.Size = new System.Drawing.Size(534, 606);
            ((System.ComponentModel.ISupportInitialize)(this.picSHOW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picSTREAM)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label lblRUN;
        public System.Windows.Forms.PictureBox picSHOW;
        public System.Windows.Forms.PictureBox picSTREAM;
        public System.Windows.Forms.Label ln1_AutoIdle;
        public System.Windows.Forms.Label ln1_PPID;
        public System.Windows.Forms.Label ln2_PressSet;
        public System.Windows.Forms.Label ln2_PressMon;
        public System.Windows.Forms.Label ln2_Step_Total;
        public System.Windows.Forms.Label ln3_ValveMon;
        public System.Windows.Forms.Label ln3_ValveSet;
        public System.Windows.Forms.Label ln3_RF_MON;
        public System.Windows.Forms.Label ln3_RF_SET;
        public System.Windows.Forms.Label ln3_RFr_MON;
        public System.Windows.Forms.Label ln3_RFr_SET;
        public System.Windows.Forms.Label ln4_Gas2_MON;
        public System.Windows.Forms.Label ln4_Gas2_SET;
        public System.Windows.Forms.Label ln4_Gas1_MON;
        public System.Windows.Forms.Label ln4_Gas1_SET;
        public System.Windows.Forms.Label ln8_Temp3_MON;
        public System.Windows.Forms.Label ln8_Temp3_SET;
        public System.Windows.Forms.Label ln7_Temp2_MON;
        public System.Windows.Forms.Label ln7_Temp2_SET;
        public System.Windows.Forms.Label ln6_Temp1_MON;
        public System.Windows.Forms.Label ln6_Temp1_SET;
        public System.Windows.Forms.Label ln9_EPD_MON;
        public System.Windows.Forms.Label ln9_EPD_SET;
        public System.Windows.Forms.Label ln10_TIME_SET;
        public System.Windows.Forms.Label ln10_TIME_MON;
        public System.Windows.Forms.Label ln11_CYCLE_MON;
        public System.Windows.Forms.Label ln11_CYCLE_SET;
        public System.Windows.Forms.Label ln11_CYCLE_STEP;
        public System.Windows.Forms.Label ln11_CYCLE_TEXT;
        public System.Windows.Forms.Label ln2_Step_Cur;
        public System.Windows.Forms.Label lblTIME;
        public System.Windows.Forms.CheckBox checkView;
    }
}
