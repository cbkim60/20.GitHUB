﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using OpenCvSharp;
using OpenCvSharp.ML;

using System.Diagnostics;

namespace enUltima3Capture
{
    public class ImageTextInfo
    {
        public int ImageId { set; get; }
        public int ImageType { set; get; }
        public String Text { set; get; }
    }

    public class ImageInfo : ImageTextInfo
    {
        public Mat Image { set; get; }
        public int ImageGroupId { set; get; }
        //public int ImageId { set; get; }

        //public int ImageType { set; get; }
        //public String Text { set; get; }
    }

    class knOCR
    {
        private const double Thresh = 80;
        private const double ThresholdMaxVal = 255;

        public KNearest m_pKN = null;

        public IList<ImageInfo> ReadTrainingImages(string path, string ext)
        {
            var images = new List<ImageInfo>();
            if (Directory.Exists(path) == false)
                return (images);

            var imageId = 1;
            imageId = 2;
            foreach (var dir in new DirectoryInfo(path).GetDirectories())
            {
                Debug.WriteLine(String.Format("NAME]{0}", dir.Name));
                //if ((dir.Name.ToLower().IndexOf("back") >= 0) || (dir.Name.ToLower().IndexOf("bkup") >= 0))
                if(dir.Name.Length > 2)
                    continue;
                var groupId = 10000;
                String curText = dir.Name;
                int curType = OcrUltima3.TEXT_TYPE_DIGIT;
                
                bool bLocalFind = false;
                if(int.TryParse(dir.Name, out groupId) == false)
                {
                    if (dir.Name.Substring(0, 1) == "D")
                        curType = OcrUltima3.TEXT_TYPE_DIGIT;
                    else if (dir.Name.Substring(0, 1) == "T")
                        curType = OcrUltima3.TEXT_TYPE_TEXT;
                    else if (dir.Name.Substring(0, 1) == "S")
                        curType = OcrUltima3.TEXT_TYPE_SYMBOL;
                    else
                        continue;
                    bLocalFind = true;
                }
                int dirType = curType;
                //var groupId = int.Parse(dir.Name);
                foreach (var imageFile in dir.GetFiles(ext))
                {
                    if (bLocalFind == true)
                    {
                        String[] splitName = imageFile.Name.Split('-');
                        if (splitName.Length < 2)
                        {
                            Debug.WriteLine(imageFile.Name + "--->" + splitName.Length);
                            continue;
                        }
                        curType = dirType;
                        switch (dirType)
                        { 
                            case OcrUltima3.TEXT_TYPE_TEXT:
                                // #A-0.png, e-0.png
                                curText = splitName[0];
                                if (splitName[0].Substring(0, 1) == "#")
                                    curText = splitName[0].Substring(1);
                                // to--0.png
                                if (splitName.Length > 2)
                                {
                                    Debug.WriteLine(String.Format("\t===>LARGE TEXT]{0}<=={1}", curText, curText.Length));
                                    curText += "-";
                                }
                                break;
                            case OcrUltima3.TEXT_TYPE_SYMBOL:
                                curText = splitName[0];
                                Debug.WriteLine(String.Format("SYMBOL={0} {1} ==> {2}", imageId, imageFile.Name, curText));
                                // ###COLON-0.png, ###DOT-0.png, ###SLASH-0.png
                                curText = splitName[0].Replace("#", "");
                                //curType = OcrUltima3.TEXT_TYPE_SYMBOL;
                                if (splitName[0].IndexOf("COLON") >= 0)
                                {
                                    curText = ":";
                                    curType = OcrUltima3.TEXT_TYPE_TIME;
                                }
                                else if (splitName[0].IndexOf("DOT") >= 0)
                                {
                                    curText = ".";
                                    curType = OcrUltima3.TEXT_TYPE_FLOAT;
                                }
                                else if (splitName[0].IndexOf("SLASH") >= 0)
                                {
                                    curText = "/";
                                    curType = OcrUltima3.TEXT_TYPE_MATH;
                                }
                                Debug.WriteLine("\t====>RESULT]" + curText);
                                break;
                            case OcrUltima3.TEXT_TYPE_DIGIT:
                            default:
                                curText = splitName[0];
                                break;
                        }
                    }
                    if(curText.Length > 1)
                    {
                        Debug.WriteLine(String.Format("LARGE={0} {1} ==> {2},{3}", imageId, imageFile.Name, curText, curType));
                    }

                    var image = processTrainingImage(new Mat(imageFile.FullName, ImreadModes.Grayscale));
                    if (image == null)
                    {
                        Debug.WriteLine(String.Format("!!!!!!!!!!! IMAGE NULL]{0} in {1}", imageFile.Name, dir.Name));
                        continue;
                    }

                    images.Add(new ImageInfo
                    {
                        Image = image,
                        ImageId = imageId++,
                        ImageGroupId = groupId,
                        ImageType = curType,
                        Text = curText
                    });
                }
            }

            return images;
        }

        public KNearest TrainData(IList<ImageInfo> trainingImages)
        {
            var samples = new Mat();
            foreach (var trainingImage in trainingImages)
            {
                samples.PushBack(trainingImage.Image);
            }

            var labels = trainingImages.Select(x => x.ImageGroupId).ToArray();
            var responses = new Mat(labels.Length, 1, MatType.CV_32SC1, labels);
            var tmp = responses.Reshape(1, 1); //make continuous
            var responseFloat = new Mat();
            tmp.ConvertTo(responseFloat, MatType.CV_32FC1); // Convert  to float

            var kNearest = KNearest.Create();
            kNearest.Train(samples, SampleTypes.RowSample, responseFloat); // Train with sample and responses
            return kNearest;
        }

        public void TrainData2(IList<ImageInfo> trainingImages)
        {
            var samples = new Mat();
            foreach (var trainingImage in trainingImages)
            {
                samples.PushBack(trainingImage.Image);
            }

            //var labels = trainingImages.Select(x => x.ImageGroupId).ToArray();
            var labels = trainingImages.Select(x => x.ImageId).ToArray();
            var responses = new Mat(labels.Length, 1, MatType.CV_32SC1, labels);
            var tmp = responses.Reshape(1, 1); //make continuous
            var responseFloat = new Mat();
            tmp.ConvertTo(responseFloat, MatType.CV_32FC1); // Convert  to float

            if (m_pKN != null)
                m_pKN.Dispose();

            m_pKN = KNearest.Create();
            m_pKN.Train(samples, SampleTypes.RowSample, responseFloat); // Train with sample and responses
        }

        public static KNearest TrainData3(IList<ImageInfo> trainingImages)
        {
            var samples = new Mat();
            foreach (var trainingImage in trainingImages)
            {
                samples.PushBack(trainingImage.Image);
            }

            //var labels = trainingImages.Select(x => x.ImageGroupId).ToArray();
            var labels = trainingImages.Select(x => x.ImageId).ToArray();
            var responses = new Mat(labels.Length, 1, MatType.CV_32SC1, labels);
            var tmp = responses.Reshape(1, 1); //make continuous
            var responseFloat = new Mat();
            tmp.ConvertTo(responseFloat, MatType.CV_32FC1); // Convert  to float

            KNearest pKn = KNearest.Create();
            pKn.Train(samples, SampleTypes.RowSample, responseFloat); // Train with sample and responses
            return (pKn);
        }


        private static Mat processTrainingImage(Mat gray)
        {
            var threshImage = new Mat();
            //Cv2.Threshold(gray, threshImage, Thresh, ThresholdMaxVal, ThresholdTypes.BinaryInv); // Threshold to find contour

            Cv2.Threshold(gray, threshImage, Thresh, ThresholdMaxVal,
               ThresholdTypes.Binary | ThresholdTypes.Otsu);

            Mat matBitWise = new Mat();
            Cv2.BitwiseAnd(threshImage, threshImage, matBitWise, threshImage);
            threshImage = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);
            Mat runGray = new Mat();
            //runGray = matBitWise.Threshold(180, 255, ThresholdTypes.Binary);

            runGray = gray.Clone();

            Point[][] contours;
            HierarchyIndex[] hierarchyIndexes;
            Cv2.FindContours(
                runGray,
                out contours,
                out hierarchyIndexes,
                mode: RetrievalModes.CComp,
                method: ContourApproximationModes.ApproxSimple);

            if (contours.Length == 0)
            {
                return null;
            }

            Mat result = null;

            var contourIndex = 0;
            while ((contourIndex >= 0))
            {
                var contour = contours[contourIndex];

                var boundingRect = Cv2.BoundingRect(contour); //Find bounding rect for each contour
                var roi = new Mat(runGray, boundingRect); //Crop the image

                //Cv2.ImShow("src", gray);
                //Cv2.ImShow("roi", roi);
                //Cv.WaitKey(0);

                var resizedImage = new Mat();
                var resizedImageFloat = new Mat();
                Cv2.Resize(roi, resizedImage, new Size(10, 10)); //resize to 10X10
                resizedImage.ConvertTo(resizedImageFloat, MatType.CV_32FC1); //convert to float
                result = resizedImageFloat.Reshape(1, 1);

                contourIndex = hierarchyIndexes[contourIndex].Next;
            }

            return result;
        }
    }
}
