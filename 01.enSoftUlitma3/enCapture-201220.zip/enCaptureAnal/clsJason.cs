﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Diagnostics;
using enUltima3Capture;

namespace enCaptureAnal
{
    class clsJason
    {
        public List<jasonOcrRect> m_pOcrItems = new List<jasonOcrRect>();
        public jasonOcrRect m_pBaseRect = new jasonOcrRect();

        public void readJason(String strFileName, String baseToken)
        {
            m_pOcrItems.Clear();
            if (System.IO.File.Exists(strFileName) == false)
            {
                Debug.WriteLine("JASON] NOT EXISTS=" + strFileName);
                return;
            }
            String tokenName = "";
            try
            {
                String allText = System.IO.File.ReadAllText(strFileName).Replace("\t", "");
                String allRead = allText.Replace(" ", "");

                tokenName = baseToken;
                JObject jObj = JObject.Parse(allRead);
                JToken idToken = jObj[tokenName];
                String mainString = idToken.ToString();
                JObject jDevObj = JObject.Parse(mainString);

                // "Rect":{"Width":1271,"Height":400},
                tokenName = "Rect";
                idToken = jDevObj[tokenName];
                String mainRect = idToken.ToString();
                JObject jMainObj = JObject.Parse(mainRect);
                m_pBaseRect.Width = Convert.ToInt32(jMainObj["Width"].ToString());
                m_pBaseRect.Height = Convert.ToInt32(jMainObj["Height"].ToString());
                String runToken = "";
                for (int n = 0; n < 100; n++)
                {
                    runToken = "";
                    int nRunLine = -1, nRunSub = -1;
                    switch (n)
                    {
                        case 0: runToken = "Verify-SET"; break;
                        case 1: runToken = "Verify-CYCLE"; break;
                        case 2: runToken = "auto-idle"; nRunLine = 0; nRunSub = 0; break;
                        case 3: runToken = "PPID"; nRunLine = 0; nRunSub = 1; break;
                        case 4: runToken = "PRESS-SET"; nRunLine = 1; nRunSub = 0; break;
                        case 5: runToken = "PRESS-MON"; nRunLine = 1; nRunSub = 1; break;
                        case 6: runToken = "STEP"; nRunLine = 1; nRunSub = 2; break;
                        case 7: runToken = "VALVE-SET"; nRunLine = 2; nRunSub = 0; break;
                        case 8: runToken = "VALVE-MON"; nRunLine = 2; nRunSub = 1; break;
                        case 9: runToken = "RF-SET"; nRunLine = 2; nRunSub = 2; break;
                        case 10: runToken = "RF-MON"; nRunLine = 2; nRunSub = 3; break;
                        case 11: runToken = "RFr-SET"; nRunLine = 2; nRunSub = 4; break;
                        case 12: runToken = "RFr-MON"; nRunLine = 2; nRunSub = 5; break;
                        case 13: runToken = "GAS1-SET"; nRunLine = 3; nRunSub = 0; break;
                        case 14: runToken = "GAS1-MON"; nRunLine = 3; nRunSub = 1; break;
                        case 15: runToken = "GAS2-SET"; nRunLine = 3; nRunSub = 2; break;
                        case 16: runToken = "GAS2-MON"; nRunLine = 3; nRunSub = 3; break;
                        case 17: runToken = "TEMP1-SET"; nRunLine = 4; nRunSub = 0; break;
                        case 18: runToken = "TEMP1-MON"; nRunLine = 4; nRunSub = 1; break;
                        case 19: runToken = "TEMP2-SET"; nRunLine = 4; nRunSub = 2; break;
                        case 20: runToken = "TEMP2-MON"; nRunLine = 4; nRunSub = 3; break;
                        case 21: runToken = "TEMP3-SET"; nRunLine = 4; nRunSub = 4; break;
                        case 22: runToken = "TEMP3-MON"; nRunLine = 4; nRunSub = 5; break;
                        case 23: runToken = "EPD-SET"; nRunLine = 5; nRunSub = 0; break;
                        case 24: runToken = "EPD-MON"; nRunLine = 5; nRunSub = 1; break;
                        case 25: runToken = "TIME-SET"; nRunLine = 5; nRunSub = 2; break;
                        case 26: runToken = "TIME-MON"; nRunLine = 5; nRunSub = 3; break;
                        case 27: runToken = "CYCLE-SET"; nRunLine = 6; nRunSub = 0; break;
                        case 28: runToken = "CYCLE-MON"; nRunLine = 6; nRunSub = 1; break;
                        case 29: runToken = "auto-end"; nRunLine = 6; nRunSub = 2; break;
                        case 30: runToken = "last"; nRunLine = 6; nRunSub = 3; break;
                    }
                    if (runToken.Length == 0)
                        break;
                    tokenName = runToken;
                    JToken jTokRun = jDevObj[tokenName];
                    if (jTokRun != null)
                    {
                        String itemRect = jTokRun.ToString();
                        JObject jItemObj = JObject.Parse(itemRect);
                        m_pBaseRect.Width = Convert.ToInt32(jMainObj["Width"].ToString());
                        // "Verify-SET":{"x":291,"y":8,"Width":129,"Height":22,"Type":0,"Verify":"SET"},
                        jasonOcrRect pRect = new jasonOcrRect();
                        pRect.Name = tokenName;
                        pRect.X = Convert.ToInt32(jItemObj["x"].ToString());
                        pRect.Y = Convert.ToInt32(jItemObj["y"].ToString());
                        pRect.Width = Convert.ToInt32(jItemObj["Width"].ToString());
                        pRect.Height = Convert.ToInt32(jItemObj["Height"].ToString());
                        pRect.Type = Convert.ToInt32(jItemObj["Type"].ToString());
                        pRect.Verify = jItemObj["Verify"].ToString();
                        pRect.Line = nRunLine;
                        pRect.Step = nRunSub;
                        m_pOcrItems.Add(pRect);
                    }
                }
            }
            catch(Exception ex)
            {
                Debug.WriteLine(String.Format("!!!!!!!!!! FAILED] token={0} Message={1}", tokenName, ex.Message));
                m_pOcrItems.Clear();
            }
            Debug.WriteLine("---------> ITEMS]" + m_pOcrItems.Count);
        }
    }
}
